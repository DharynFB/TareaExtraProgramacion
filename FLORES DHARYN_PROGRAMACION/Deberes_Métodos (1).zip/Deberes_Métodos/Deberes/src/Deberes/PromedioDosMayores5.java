package Deberes;
import java.util.Scanner;
// EJERCICIO 5
public class PromedioDosMayores5 {

    public void CargarNotas() {
        Scanner teclado = new Scanner(System.in);
        double nota1, nota2, nota3;

        System.out.print("Ingrese la primera nota: ");
        nota1 = teclado.nextDouble();
        System.out.print("Ingrese la segunda nota: ");
        nota2 = teclado.nextDouble();
        System.out.print("Ingrese la tercera nota: ");
        nota3 = teclado.nextDouble();

        CalcularPromedioDosMayores(nota1, nota2, nota3);
    }
    public void CalcularPromedioDosMayores(double n1, double n2, double n3) {
        double sumaDosMayores = 0;
        double menor;
        // Encontrar la menor nota y restarla de la suma total
        if (n1 <= n2 && n1 <= n3) {
            menor = n1;
        } else if (n2 <= n1 && n2 <= n3) {
            menor = n2;
        } else {
            menor = n3;
        }
        sumaDosMayores = n1 + n2 + n3 - menor;
        double promedio = sumaDosMayores / 2;

        System.out.println("\n--- Resultado ---");
        System.out.println("Promedio de las dos notas mayores: " + promedio);
    }

    public static void main(String[] args) {
        PromedioDosMayores5 promedio = new PromedioDosMayores5();
        promedio.CargarNotas();
    }
}

