package Deberes;
import java.util.Scanner;

//EJERCICIO 1 

public class FactorialNumero1 {

    public void CargarNumero() {
        Scanner teclado = new Scanner(System.in);
        int numero, resultado;

        System.out.print("Ingrese un número para calcular su factorial: ");
        numero = teclado.nextInt();

        resultado = CalcularFactorial(numero);

        System.out.println("El factorial de " + numero + " es: " + resultado);
    }

    public int CalcularFactorial(int n) {
        int factorial = 1;

        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        return factorial;
    }

    public static void main(String[] args) {
        FactorialNumero1 factorial = new FactorialNumero1();
        factorial.CargarNumero();
    }
}


