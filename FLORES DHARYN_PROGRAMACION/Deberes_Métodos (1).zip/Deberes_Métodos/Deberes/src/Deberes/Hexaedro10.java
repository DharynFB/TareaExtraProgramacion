package Deberes;

import java.util.Scanner;

// EJERCICIO 10
 
public class Hexaedro10 {

    public void IngresarLado() {
        Scanner teclado = new Scanner(System.in);
        double lado;

        System.out.print("Ingrese el lado del hexaedro (cubo): ");
        lado = teclado.nextDouble();

        CalcularResultados(lado);
    }

    public void CalcularResultados(double l) {
        double areaBase = l * l;
        double areaLateral = 4 * l * l;
        double areaTotal = 6 * l * l;
        double volumen = l * l * l;

        System.out.println("\n--- Resultados del Hexaedro ---");
        System.out.println("Área de la base: " + areaBase);
        System.out.println("Área lateral: " + areaLateral);
        System.out.println("Área total: " + areaTotal);
        System.out.println("Volumen: " + volumen);
    }

    public static void main(String[] args) {
        Hexaedro10 hexaedro = new Hexaedro10();
        hexaedro.IngresarLado();
    }
}

