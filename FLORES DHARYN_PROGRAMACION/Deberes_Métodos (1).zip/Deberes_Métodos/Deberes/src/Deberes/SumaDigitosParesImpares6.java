package Deberes;

import java.util.Scanner;

//EJEMPLO 6
public class SumaDigitosParesImpares6 {

    public void IngresarNumero() {
        Scanner teclado = new Scanner(System.in);
        int numero;

        System.out.print("Ingrese un número entero: ");
        numero = teclado.nextInt();

        CalcularSumaDigitos(numero);
    }

    public void CalcularSumaDigitos(int num) {
        int digito, sumaPares = 0, sumaImpares = 0;

        while (num != 0) {
            digito = num % 10;

            if (digito % 2 == 0) {
                sumaPares += digito;
            } else {
                sumaImpares += digito;
            }

            num = num / 10;
        }
        System.out.println("--- Resultado ---");
        System.out.println("Suma de dígitos pares: " + sumaPares);
        System.out.println("Suma de dígitos impares: " + sumaImpares);
    }
    public static void main(String[] args) {
        SumaDigitosParesImpares6 suma = new SumaDigitosParesImpares6();
        suma.IngresarNumero();
    }
}
