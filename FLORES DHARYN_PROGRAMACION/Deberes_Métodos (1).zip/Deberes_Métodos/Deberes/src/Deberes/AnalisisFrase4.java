package Deberes;

import java.util.Scanner;

// EJERCICIO 4
 
public class AnalisisFrase4 {

    public void IniciarProceso() {
        Scanner teclado = new Scanner(System.in);
        char opcion;

        do {
            System.out.print("Ingrese una frase: ");
            String frase = teclado.nextLine();

            int palabras = ContarPalabras(frase);
            int letras = ContarLetras(frase);
            int vocales = ContarVocales(frase);

            System.out.println("--- Resultados ---");
            System.out.println("Cantidad de palabras: " + palabras);
            System.out.println("Cantidad de letras: " + letras);
            System.out.println("Cantidad de vocales: " + vocales);
            System.out.println();

            System.out.print("¿Desea repetir el proceso? (s/n): ");
            opcion = teclado.next().toLowerCase().charAt(0);
            teclado.nextLine(); // limpiar el buffer
        } while (opcion == 's');
    }

    public int ContarPalabras(String frase) {
        frase = frase.trim();
        if (frase.isEmpty()) {
            return 0;
        }
        int contador = 1;
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) == ' ') {
                contador++;
            }
        }
        return contador;
    }

    public int ContarLetras(String frase) {
        int contador = 0;
        for (int i = 0; i < frase.length(); i++) {
            char c = frase.charAt(i);
            if (Character.isLetter(c)) {
                contador++;
            }
        }
        return contador;
    }

    public int ContarVocales(String frase) {
        int contador = 0;
        frase = frase.toLowerCase();
        for (int i = 0; i < frase.length(); i++) {
            char c = frase.charAt(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                contador++;
            }
        }
        return contador;
    }

    public static void main(String[] args) {
        AnalisisFrase4 analisis = new AnalisisFrase4();
        analisis.IniciarProceso();
    }
}

