package Deberes;

import java.util.Scanner;

//EJERCICIO 2
 
public class SumaCincoNumeros2 {

    public void CargarNumeros() {
        Scanner teclado = new Scanner(System.in);
        int n1, n2, n3, n4, n5, suma;

        System.out.print("Ingrese el primer número: ");
        n1 = teclado.nextInt();
        System.out.print("Ingrese el segundo número: ");
        n2 = teclado.nextInt();
        System.out.print("Ingrese el tercer número: ");
        n3 = teclado.nextInt();
        System.out.print("Ingrese el cuarto número: ");
        n4 = teclado.nextInt();
        System.out.print("Ingrese el quinto número: ");
        n5 = teclado.nextInt();

        suma = CalcularSuma(n1, n2, n3, n4, n5);

        System.out.println("La suma de los 5 números es: " + suma);
    }

    public int CalcularSuma(int a, int b, int c, int d, int e) {
        return a + b + c + d + e;
    }

    public static void main(String[] args) {
        SumaCincoNumeros2 suma = new SumaCincoNumeros2();
        suma.CargarNumeros();
    }
}


