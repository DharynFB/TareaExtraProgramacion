package Deberes;

import java.util.Scanner;

//EJERCICIO 12

public class PrismaPentagonal12 {

    public void IngresarDatos() {
        Scanner teclado = new Scanner(System.in);
        double perimetro, apotema, altura;

        System.out.print("Ingrese el perímetro de la base: ");
        perimetro = teclado.nextDouble();
        System.out.print("Ingrese el apotema de la base: ");
        apotema = teclado.nextDouble();
        System.out.print("Ingrese la altura del prisma: ");
        altura = teclado.nextDouble();

        CalcularAreas(perimetro, apotema, altura);
    }

    public void CalcularAreas(double p, double a, double h) {
        double areaBase = (p * a) / 2;
        double areaLateral = p * h;
        double areaTotal = 2 * areaBase + areaLateral;

        System.out.println("\n--- Resultados del Prisma Pentagonal ---");
        System.out.println("Área de la base: " + areaBase);
        System.out.println("Área lateral: " + areaLateral);
        System.out.println("Área total: " + areaTotal);
    }

    public static void main(String[] args) {
        PrismaPentagonal12 prisma = new PrismaPentagonal12();
        prisma.IngresarDatos();
    }
}

