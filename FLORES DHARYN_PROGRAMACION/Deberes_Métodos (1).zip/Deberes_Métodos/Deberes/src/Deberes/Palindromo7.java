package Deberes;

import java.util.Scanner;
// EJERCICIO 7
public class Palindromo7 {

    public void IngresarPalabra() {
        Scanner teclado = new Scanner(System.in);
        String palabra;

        System.out.print("Ingrese una palabra: ");
        palabra = teclado.nextLine();

        if (EsPalindromo(palabra)) {
            System.out.println("La palabra \"" + palabra + "\" es un palíndromo.");
        } else {
            System.out.println("La palabra \"" + palabra + "\" no es un palíndromo.");
        }
    }
    public boolean EsPalindromo(String palabra) {
        palabra = palabra.toLowerCase(); // ignorar mayúsculas
        int inicio = 0;
        int fin = palabra.length() - 1;

        while (inicio < fin) {
            if (palabra.charAt(inicio) != palabra.charAt(fin)) {
                return false;
            }
            inicio++;
            fin--;
        }

        return true;
    }

    public static void main(String[] args) {
        Palindromo7 objeto = new Palindromo7();
        objeto.IngresarPalabra();
    }
}

