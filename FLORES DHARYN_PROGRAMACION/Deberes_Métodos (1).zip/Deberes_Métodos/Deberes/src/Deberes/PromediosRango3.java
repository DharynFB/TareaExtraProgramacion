package Deberes;
import java.util.Scanner;
// EJERCICIO 3
public class PromediosRango3 {
    public void IniciarProceso() {
        Scanner teclado = new Scanner(System.in);
        char opcion;
        do {
            int inicio, fin;
            System.out.print("Ingrese el número inicial del rango: ");
            inicio = teclado.nextInt();
            System.out.print("Ingrese el número final del rango: ");
            fin = teclado.nextInt();

            CalcularPromedios(inicio, fin);

            System.out.print("¿Desea repetir el proceso? (s/n): ");
            opcion = teclado.next().toLowerCase().charAt(0);
        } while (opcion == 's');
    }
    public void CalcularPromedios(int inicio, int fin) {
        int sumaTotal = 0, cantidadTotal = 0;
        int sumaPares = 0, cantidadPares = 0;
        int sumaImpares = 0, cantidadImpares = 0;
        int sumaPrimos = 0, cantidadPrimos = 0;
        for (int i = inicio; i <= fin; i++) {
            sumaTotal += i;
            cantidadTotal++;
            if (i % 2 == 0) {
                sumaPares += i;
                cantidadPares++;
            } else {
                sumaImpares += i;
                cantidadImpares++;
            }
            if (EsPrimo(i)) {
                sumaPrimos += i;
                cantidadPrimos++;
            }
        }
        System.out.println("\n--- Resultados ---");
        System.out.println("Promedio total: " + (cantidadTotal > 0 ? (double)sumaTotal / cantidadTotal : 0));
        System.out.println("Promedio de pares: " + (cantidadPares > 0 ? (double)sumaPares / cantidadPares : 0));
        System.out.println("Promedio de impares: " + (cantidadImpares > 0 ? (double)sumaImpares / cantidadImpares : 0));
        System.out.println("Promedio de primos: " + (cantidadPrimos > 0 ? (double)sumaPrimos / cantidadPrimos : 0));
        System.out.println();
    }
    public boolean EsPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        PromediosRango3 promedios = new PromediosRango3();
        promedios.IniciarProceso();
    }
}

