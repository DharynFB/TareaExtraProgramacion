package Deberes;

import java.util.Scanner;

//EJERCICIO 9

public class Esfera9 {

    public void IngresarRadio() {
        Scanner teclado = new Scanner(System.in);
        double radio;

        System.out.print("Ingrese el radio de la esfera: ");
        radio = teclado.nextDouble();

        CalcularResultados(radio);
    }

    public void CalcularResultados(double r) {
        double pi = 3.1416;
        double area = 4 * pi * r * r;
        double volumen = (4.0 / 3) * pi * r * r * r;

        System.out.println("\n--- Resultados de la Esfera ---");
        System.out.println("Área: " + area);
        System.out.println("Volumen: " + volumen);
    }

    public static void main(String[] args) {
        Esfera9 esfera = new Esfera9();
        esfera.IngresarRadio();
    }
}

