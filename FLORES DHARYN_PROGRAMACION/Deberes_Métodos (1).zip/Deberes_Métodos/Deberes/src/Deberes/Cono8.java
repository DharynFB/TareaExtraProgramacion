package Deberes;

import java.util.Scanner;
// EJERCICIO 8
public class Cono8 {
    public void IngresarDatos() {
        Scanner teclado = new Scanner(System.in);
        double radio, generatriz, altura;

        System.out.print("Ingrese el radio del cono: ");
        radio = teclado.nextDouble();

        System.out.print("Ingrese la generatriz del cono: ");
        generatriz = teclado.nextDouble();

        System.out.print("Ingrese la altura del cono: ");
        altura = teclado.nextDouble();

        CalcularResultados(radio, generatriz, altura);
    }
    public void CalcularResultados(double r, double g, double h) {
        double pi = 3.1416;
        double areaBase = pi * r * r;
        double areaLateral = pi * r * g;
        double areaTotal = areaBase + areaLateral;
        double volumen = (pi * r * r * h) / 3;

        System.out.println("\n--- Resultados del Cono ---");
        System.out.println("Área de la base: " + areaBase);
        System.out.println("Área lateral: " + areaLateral);
        System.out.println("Área total: " + areaTotal);
        System.out.println("Volumen: " + volumen);
    }

    public static void main(String[] args) {
        Cono8 cono = new Cono8();
        cono.IngresarDatos();
    }
}

