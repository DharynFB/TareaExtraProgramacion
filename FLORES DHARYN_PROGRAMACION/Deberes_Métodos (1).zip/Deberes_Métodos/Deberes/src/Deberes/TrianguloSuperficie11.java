package Deberes;
import java.util.Scanner;
//EJERCICIO 11
public class TrianguloSuperficie11 {
    public void IngresarCoordenadas() {
        Scanner teclado = new Scanner(System.in);
        double x1, y1, x2, y2, x3, y3;

        System.out.println("Ingrese coordenadas del punto P1:");
        System.out.print("x1: ");
        x1 = teclado.nextDouble();
        System.out.print("y1: ");
        y1 = teclado.nextDouble();

        System.out.println("Ingrese coordenadas del punto P2:");
        System.out.print("x2: ");
        x2 = teclado.nextDouble();
        System.out.print("y2: ");
        y2 = teclado.nextDouble();

        System.out.println("Ingrese coordenadas del punto P3:");
        System.out.print("x3: ");
        x3 = teclado.nextDouble();
        System.out.print("y3: ");
        y3 = teclado.nextDouble();

        double area = CalcularArea(x1, y1, x2, y2, x3, y3);
        System.out.println("\n--- Resultados ---");
        System.out.println("Área del triángulo: " + area);
    }
    public double CalcularArea(double x1, double y1, double x2, double y2, double x3, double y3) {
        double determinante = x1 * (y2 - y3) +
                              x2 * (y3 - y1) +
                              x3 * (y1 - y2);
        double area = Math.abs(determinante) / 2.0;
        return area;
    }

    public static void main(String[] args) {
        TrianguloSuperficie11 triangulo = new TrianguloSuperficie11();
        triangulo.IngresarCoordenadas();
    }
}

