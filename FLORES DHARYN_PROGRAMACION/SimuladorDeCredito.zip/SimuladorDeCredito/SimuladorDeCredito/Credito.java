import java.util.Scanner;

public class Credito {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        // ========== DATOS DEL CLIENTE ==========
        System.out.println("**********************      BANCO PINK :)    **********************");
        System.out.println("=== DATOS DEL CLIENTE ===");
        System.out.print("Cédula: ");
        String cedula = teclado.nextLine();
        System.out.print("Nombres completos: ");
        String nombres = teclado.nextLine();
        System.out.print("Fecha de nacimiento (dd/mm/aaaa): ");
        String fechaNacimiento = teclado.nextLine();
        // ========== VALIDACION DE SEGUROS ==========
        System.out.println("\n=== VALIDACION DE SEGUROS ===");
        System.out.println("¿Tiene alguna enfermedad catastrofica? (s/n)");
        String enfermedad = teclado.nextLine();
        
        if(enfermedad.equalsIgnoreCase("s")) {
            
            System.out.println("Lo sentimos, no califica para el seguro de desgravamen.");
            return;
        } else {
            System.out.println("Validación de seguros aprobada.");
        }

        System.out.println("Ingrese fecha inicial:");
        System.out.print("Día (1-31): ");
        int dia = teclado.nextInt();
        
        System.out.print("Mes (1-12): ");
        int mes = teclado.nextInt();
        
        System.out.print("Año (ej: 2023): ");
        int anio = teclado.nextInt();
        // Función simple para obtener días del mes
        int diasEnMes;
        if(mes == 2) { // Febrero
            boolean esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
            diasEnMes = esBisiesto ? 29 : 28;
        } else if(mes == 4 || mes == 6 || mes == 9 || mes == 11) {
             diasEnMes = 30; // Abril, Junio, Septiembre, Noviembre
        } else {
            diasEnMes = 31; // Resto de meses
        }
        

        
        // ========== DATOS DEL CRÉDITO ==========
        System.out.println("\n=== DATOS DEL CREDITO ===");
        int tipoCredito = 0;
        double monto = 0;
        int plazo = 0;
        int metodoPago = 0;
        double tea = 0;
        String nombreCredito = "";
        
        // Selección de tipo de crédito
        System.out.println("\nSeleccione el tipo de crédito:");
        System.out.println("1. Preciso (Consumo) - TEA: 15.6%");
        System.out.println("2. Línea Abierta (Rotativa) - TEA: 13.0%");
        System.out.println("3. Hipotecario Vivienda - TEA: 10.93%");
        System.out.println("4. Vivienda VIP - TEA: 4.98%");
        System.out.println("5. Vivienda VIS - TEA: 4.99%");
        System.out.println("6. Educación Superior - TEA: 9.38%");
        System.out.print("Opción: ");

        // Asignar TEA y nombre según opción
        if(teclado.hasNextInt()) {
            tipoCredito = teclado.nextInt();
    switch(tipoCredito) {
        case 1:
            tea = 15.6;
            nombreCredito = "Preciso (Consumo)";
            break;
        case 2:
            tea = 13.0;
            nombreCredito = "Línea Abierta (Rotativa)";
            break;
        case 3:
            tea = 10.93;
            nombreCredito = "Hipotecario Vivienda";
            break;
        case 4:
            tea = 4.98;
            nombreCredito = "Vivienda VIP";
            break;
        case 5:
            tea = 4.99;
            nombreCredito = "Vivienda VIS";
            break;
        case 6:
            tea = 9.38;
            nombreCredito = "Educación Superior";
            break;
        default:
            System.out.println("Opción inválida");
            tipoCredito = 0; // Para repetir el bucle
    }
        } else {
            System.out.println("Entrada inválida. Por favor ingrese un número.");
            teclado.next(); // Limpiar buffer
            tipoCredito = 0; // Para repetir el bucle
        }  
        
        // Solicitar monto
        do {
            System.out.print("\nIngrese el monto del crédito: ");
            if(teclado.hasNextDouble()) {
                monto = teclado.nextDouble();
                if(monto <= 0) {
                    System.out.println("El monto debe ser mayor que cero.");
                }
            } else {
                System.out.println("Entrada inválida. Por favor ingrese un número.");
                teclado.next();
            }
        } while(monto <= 0);
        if(tipoCredito >= 3 && tipoCredito <= 5) {
            System.out.print("Ingrese el valor comercial de la vivienda: $");
            double valorVivienda = teclado.nextDouble();
            
            while(monto > valorVivienda) {
                System.out.printf("Error: El préstamo ($%,.2f) no puede exceder el valor de la vivienda ($%,.2f)\n", 
                monto, valorVivienda);
                System.out.print("Ingrese nuevo monto: $");
                monto = teclado.nextDouble();
            }
        }
        // Solicitar plazo
        do {
            System.out.print("\nIngrese el plazo en meses (3-720): ");
            if(teclado.hasNextInt()) {
                plazo = teclado.nextInt();
                
                // ===== NUEVA VALIDACIÓN CON LÍMITES ESPECÍFICOS =====
                int plazoMinimo = 3;
                int plazoMaximoGeneral = 720;
                int plazoMaximoConsumo = 60; // Límite para créditos de consumo (tipos 1 y 2)
                
                if(tipoCredito == 1 || tipoCredito == 2) { // Créditos de consumo
                    if(plazo < plazoMinimo || plazo > plazoMaximoConsumo) {
                        System.out.println("Error: Para créditos de consumo el plazo debe ser entre " + plazoMinimo + " y " + plazoMaximoConsumo + " meses.");
                        continue; // Vuelve a pedir el dato
                    }
                } else { // Otros créditos (hipotecarios, educación)
                    if(plazo < plazoMinimo || plazo > plazoMaximoGeneral) {
                        System.out.println("Error: El plazo debe ser entre " + plazoMinimo + " y " + plazoMaximoGeneral + " meses.");
                        continue;
                    }
                }
                // ===== FIN DE VALIDACION =====
                
            } else {
                System.out.println("Error: Debe ingresar un número entero.");
                teclado.next(); // Limpiar buffer
            }
        } while(plazo < 3 || plazo > 720); // Mantener esta condición como "red de seguridad"
        
        // Solicitar método de pago
        do {
            System.out.println("\nSeleccione el método de pago:");
            System.out.println("1. Método Francés (Cuotas fijas)");
            System.out.println("2. Método Alemán (Amortización fija)");
            System.out.print("Opción: ");
            
            if(teclado.hasNextInt()) {
                metodoPago = teclado.nextInt();
                if(metodoPago < 1 || metodoPago > 2) {
                    System.out.println("Opción inválida. Por favor seleccione 1 o 2.");
                }
            } else {
                System.out.println("Entrada inválida. Por favor ingrese un número.");
                teclado.next();
            }
        } while(metodoPago < 1 || metodoPago > 2);
        // ========== CÁLCULO DE SEGUROS ==========
        double seguroDesgravamen = monto * 0.0005; // 0.05% para todos
        double seguroIncendio = 0;

        // Solo para créditos HIPOTECARIOS (tipos 3-5)
        if(tipoCredito >= 3 && tipoCredito <= 5) {  // Cambiamos la condición
            seguroIncendio = monto * 0.001; // 0.1%
            System.out.println("\n=== DETALLE DE SEGUROS ===");
            System.out.printf("Seguro de desgravamen (0.05%%): $%,.2f%n", seguroDesgravamen);
            System.out.printf("Seguro de incendio para vivienda (0.1%%): $%,.2f%n", seguroIncendio);
        } else {
            System.out.println("\n=== DETALLE DE SEGUROS ===");
            System.out.printf("Seguro de desgravamen (0.05%%): $%,.2f%n", seguroDesgravamen);
        }

        
        // ========== CÁLCULO DE CUOTAS ==========
        double tem = Math.pow(1 + tea/100, 1.0/12) - 1;
        double comision = monto * 0.005;
        
        System.out.println("\n\n=============================================");
        System.out.println("        SIMULACION DE CRÉDITO - DETALLE");
        System.out.println("=============================================");
        System.out.println("Cliente: " + nombres);
        System.out.println("Cédula: " + cedula);
        System.out.println("Producto: " + nombreCredito);
        System.out.printf("Monto solicitado: $%,.2f%n", monto);
        System.out.println("Plazo: " + plazo + " meses");
        System.out.println("Metodo de pago: " + (metodoPago == 1 ? "Frances" : "Aleman"));
        System.out.printf("TEA: %.2f%%%n", tea);
        System.out.printf("TEM: %.4f%%%n", tem*100);
        System.out.printf("Comisión (0.5%%): $%,.2f%n", comision);
        System.out.println("=============================================\n");
        
        double saldo = monto;
        double totalIntereses = 0;
        double totalSeguroDesgravamen = 0;
        double totalSeguroIncendio = 0;
        
        for(int cuota = 1; cuota <= plazo; cuota++) {
            // Sumamos 1 mes
            mes++;
            
            // Si pasamos de diciembre, reiniciamos a enero y sumamos 1 año
            if(mes > 12) {
                mes = 1;
                anio++;
            }
            
            // Calculamos días del mes actual (usando la misma lógica de arriba)
            int diasEnMesActual;
            if(mes == 2) {
                boolean esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
                diasEnMesActual = esBisiesto ? 29 : 28;
            } else if(mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                diasEnMesActual = 30;
            } else {
                diasEnMesActual = 31;
            }
            
            // Aseguramos que el día no exceda los días del mes
            if(dia > diasEnMesActual) {
                dia = diasEnMesActual;
            }
            

        }
        System.out.println("+-------+------------+-----------+-----------+-----------+-----------+-------------+-----------+");
        System.out.println("| Cuota |   Fecha    |  Capital  |  Interés  | Seg.Desg. | Seg.Inc.  | Valor Cuota |   Saldo   |");
        System.out.println("+-------+------------+-----------+-----------+-----------+-----------+-------------+-----------+");
        
        for(int cuota = 1; cuota <= plazo; cuota++) {
            double capital, interes, valorCuota;
            
            // Método Francés
            if(metodoPago == 1) {
                valorCuota = monto * (tem * Math.pow(1 + tem, plazo)) / (Math.pow(1 + tem, plazo) - 1);
                interes = saldo * tem;
                capital = valorCuota - interes;
            } 
            // Método Alemán
            else {
                capital = monto / plazo;
                interes = saldo * tem;
                valorCuota = capital + interes;
            }
            
            seguroDesgravamen = saldo * 0.0005;
            seguroIncendio = 0; // REINICIAR A CERO CADA MES
            // Solo para hipotecarios (tipos 3-5)
            if(tipoCredito >= 3 && tipoCredito <= 5) { 
                seguroIncendio = saldo * 0.001;
            }


            
            if(cuota == plazo) {
                capital = saldo;
                valorCuota = capital + interes + seguroDesgravamen + seguroIncendio;
            }
            
            valorCuota += seguroDesgravamen + seguroIncendio;
            saldo -= capital;
            if(saldo < 0.01) saldo = 0;

            
            totalIntereses += interes;
            totalSeguroDesgravamen += seguroDesgravamen;
            totalSeguroIncendio += seguroIncendio;

            mes++;
            if(mes > 12) {
                mes = 1;
                anio++;
            }
            
            // Asegurar que el día no exceda los días del mes actual
            int diasEnMesActual;
            if(mes == 2) {
                boolean esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
                diasEnMesActual = esBisiesto ? 29 : 28;
            } else if(mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                diasEnMesActual = 30;
            } else {
                diasEnMesActual = 31;
            }
            int diaPago = Math.min(dia, diasEnMesActual);
            
            // Imprimir la fila con formato
            System.out.printf(
                "| %5d | %02d/%02d/%04d | %9.2f | %9.2f | %9.2f | %9.2f | %11.2f | %9.2f |\n",
                cuota,
                diaPago, mes, anio,  // Fecha correctamente calculada
                capital,
                interes,
                seguroDesgravamen,
                seguroIncendio,
                valorCuota,
                saldo
            );
            

        }
        
        // ========== RESUMEN FINAL ==========
        System.out.println("\n=============================================");
        System.out.println("               RESUMEN FINAL");
        System.out.println("=============================================");
        System.out.println("Cliente: " + nombres);
        System.out.println("Cédula: " + cedula);
        System.out.println("Producto: " + nombreCredito);
  
        System.out.printf("Monto solicitado: $%,.2f%n", monto);
        System.out.printf("Capital: ", monto-comision);
        System.out.printf("Comisión inicial: $%,.2f%n", comision);

        System.out.printf("Total intereses: $%,.2f%n", totalIntereses);
        System.out.printf("Total seguro desgravamen: $%,.2f%n", totalSeguroDesgravamen);

        // Solo mostrar si es crédito vehicular
        if(tipoCredito == 1 || tipoCredito == 2) {  // CONDICIÓN NUEVA
           System.out.printf("Total seguro vehicular/incendio: $%,.2f%n", totalSeguroIncendio);
        }



        System.out.printf("Costo total del crédito: $%,.2f%n", 
            monto + comision + totalIntereses + totalSeguroDesgravamen + totalSeguroIncendio);
        System.out.println("=============================================");
        System.out.println("*******************  Gracias por probar nuestro simulador :) ***************************");
        
    }
}