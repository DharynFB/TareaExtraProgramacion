import java.util.Scanner;

public class ejercicio4 {

    public static void sumaDigitos(int numero) {
        int sumaPares = 0;
        int sumaImpares = 0;

        while (numero > 0) {
            int digito = numero % 10;

            if (digito % 2 == 0) {
                sumaPares += digito;
            } else {
                sumaImpares += digito;
            }

            numero = numero / 10;
        }

        System.out.println("Suma de dígitos pares: " + sumaPares);
        System.out.println("Suma de dígitos impares: " + sumaImpares);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numero;

        System.out.print("Ingrese un número entero positivo: ");
        numero = teclado.nextInt();

        if (numero > 0) {
            sumaDigitos(numero);
        } else {
            System.out.println("El número debe ser mayor que cero.");
        }
    }
}
