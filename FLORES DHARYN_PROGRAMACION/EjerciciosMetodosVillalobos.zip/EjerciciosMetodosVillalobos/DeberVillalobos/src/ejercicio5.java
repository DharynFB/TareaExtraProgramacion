import java.util.Scanner;

public class ejercicio5 {

    public static void tipoCaracter(char c) {
        if (Character.isDigit(c)) {
            System.out.println("Es un número.");
        } else if (Character.isUpperCase(c)) {
            if ("AEIOU".indexOf(c) != -1) {
                System.out.println("Es una vocal mayúscula.");
            } else {
                System.out.println("Es una letra mayúscula.");
            }
        } else if (Character.isLowerCase(c)) {
            if ("aeiou".indexOf(c) != -1) {
                System.out.println("Es una vocal minúscula.");
            } else {
                System.out.println("Es una letra minúscula.");
            }
        } else {
            System.out.println("Es un símbolo.");
        }
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese un carácter: ");
        String entrada = teclado.nextLine();

        if (entrada.length() == 1) {
            char caracter = entrada.charAt(0);
            tipoCaracter(caracter);
        } else {
            System.out.println("Debe ingresar un solo carácter.");
        }

        teclado.close();
    }
}
