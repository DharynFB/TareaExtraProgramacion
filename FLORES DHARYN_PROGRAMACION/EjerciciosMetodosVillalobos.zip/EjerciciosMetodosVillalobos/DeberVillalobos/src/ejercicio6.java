import java.util.Scanner;

public class ejercicio6 {

    public static double AreaRectangulo(double base, double altura) {
        double area = base * altura;
        return area;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double base, altura, area;

        System.out.print("Ingrese la base del rectángulo: ");
        base = teclado.nextDouble();

        System.out.print("Ingrese la altura del rectángulo: ");
        altura = teclado.nextDouble();

        area = AreaRectangulo(base, altura);

        System.out.println("El área del rectángulo es: " + area);

    }
}
