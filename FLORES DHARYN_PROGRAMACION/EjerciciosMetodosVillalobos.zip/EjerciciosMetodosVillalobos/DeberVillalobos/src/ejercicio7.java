import java.util.Scanner;

public class ejercicio7 {

    public static double Descuento(char tipoCliente) {
        if (tipoCliente == 'G') {
            return 15.0;
        } else if (tipoCliente == 'A') {
            return 20.0;
        } else {
            return 0.0;
        }
    }

    public static double Recargo(char tipoCliente) {
        if (tipoCliente == 'G') {
            return 10.0;
        } else if (tipoCliente == 'A') {
            return 5.0;
        } else {
            return 0.0;
        }
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        char tipoCliente, formaPago;

        System.out.print("Ingrese el tipo de cliente (G = General, A = Afiliado): ");
        tipoCliente = teclado.next().toUpperCase().charAt(0);

        System.out.print("Ingrese la forma de pago (C = Contado, P = Plazos): ");
        formaPago = teclado.next().toUpperCase().charAt(0);
        double monto;
        System.out.print("Ingrese el monto de la compra: ");
        monto = teclado.nextDouble();

        double porcentaje = 0.0;
        double ajuste = 0.0;
        double total = 0.0;

        if (formaPago == 'C') {
            porcentaje = Descuento(tipoCliente);
            ajuste = monto * (porcentaje / 100);
            total = monto - ajuste;
            System.out.println("Descuento aplicado: " + ajuste);
        } else if (formaPago == 'P') {
            porcentaje = Recargo(tipoCliente);
            ajuste = monto * (porcentaje / 100);
            total = monto + ajuste;
            System.out.println("Recargo aplicado: " + ajuste);
        } else {
            System.out.println("Forma de pago inválida.");
        }

        System.out.println("Total a pagar: " + total);

        teclado.close();
    }
}
