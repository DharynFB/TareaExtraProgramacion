import java.util.Scanner;

public class ejercicio8 {

    public static int invertirNumero(int numero) {
        int invertido = 0;

        while (numero > 0) {
            int digito = numero % 10;
            invertido = invertido * 10 + digito;
            numero = numero / 10;
        }

        return invertido;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numero,resultado;
        System.out.print("Ingrese un número entero: ");
        numero = teclado.nextInt();

        resultado = invertirNumero(numero);

        System.out.println("El número invertido es: " + resultado);

    }
}
