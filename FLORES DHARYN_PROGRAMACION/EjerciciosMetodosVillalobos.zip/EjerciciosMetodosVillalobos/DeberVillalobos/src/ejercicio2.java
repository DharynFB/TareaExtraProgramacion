import java.util.Scanner;

public class ejercicio2 {

    public static double promedio(double n1, double n2, double n3) {
        double suma;

        if (n1 <= n2 && n1 <= n3) {

            suma = n2 + n3;
        } else if (n2 <= n1 && n2 <= n3) {

            suma = n1 + n3;
        } else {

            suma = n1 + n2;
        }

        return suma / 2;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1, n2, n3;
        double resultado;

        System.out.print("Ingrese la primera nota: ");
        n1 = teclado.nextDouble();
        System.out.print("Ingrese la segunda nota: ");
        n2 = teclado.nextDouble();
        System.out.print("Ingrese la tercera nota: ");
        n3 = teclado.nextDouble();
        resultado = promedio(n1, n2, n3);
        System.out.println("El promedio de las dos notas mayores es: " + resultado);
    }

}
