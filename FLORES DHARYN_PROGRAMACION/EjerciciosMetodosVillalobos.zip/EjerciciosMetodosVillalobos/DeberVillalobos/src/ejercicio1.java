import java.util.Scanner;

public class ejercicio1 {

    // calcular el area de un cuadrado
    public static double calcularArea(double lado) {
        return lado * lado;
    }

    // calcular el perimetro de un cuadrado
    public static double calcularPerimetro(double lado) {
        return 4 * lado;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in); 
        double lado;
        double area;
        double perimetro;
        System.out.print("Ingrese el valor del lado del cuadrado: ");
        lado = teclado.nextDouble();
        area = calcularArea(lado);
        perimetro = calcularPerimetro(lado);

        System.out.println("Área del cuadrado: " + area);
        System.out.println("Perímetro del cuadrado: " + perimetro);
    }
}

