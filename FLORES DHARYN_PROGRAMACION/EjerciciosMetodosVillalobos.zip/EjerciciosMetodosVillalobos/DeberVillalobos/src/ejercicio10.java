import java.util.Scanner;

public class ejercicio10 {
    public static int[][] multiplicarMatrices(int[][] A, int[][] B) {
        int[][] C = new int[2][2];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                C[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        return C;
    }

    public static void mostrarMatriz(int[][] matriz) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int[][] A = new int[2][2];
        int[][] B = new int[2][2];

        System.out.println("Ingrese los elementos de la matriz A:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("A[" + i + "][" + j + "]: ");
                A[i][j] = teclado.nextInt();
            }
        }

        System.out.println("\nIngrese los elementos de la matriz B:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("B[" + i + "][" + j + "]: ");
                B[i][j] = teclado.nextInt();
            }
        }

        int[][] C = multiplicarMatrices(A, B);

        System.out.println("Resultado de C = A * B:");
        mostrarMatriz(C);

    }
}
