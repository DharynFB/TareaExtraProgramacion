import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class SimuladorCredito1 extends JFrame {
    private JTextField txtNombre, txtCedula, txtFechaNac, txtMonto, txtFechaInicio;
    private JSpinner spnPlazo;
    private JComboBox<String> cmbCredito, cmbMetodo;
    private JTextArea txtResultado;

    public SimuladorCredito1() {
        setTitle("Simulador de Crédito");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 720);
        setLocationRelativeTo(null); // Centrado en pantalla
        setLayout(new BorderLayout());

        Color azulClaro = new Color(173, 216, 230);
        Color fondoFormulario = new Color(240, 248, 255);
        Font etiquetaFont = new Font("Segoe UI", Font.BOLD, 14);
        Font campoFont = new Font("Segoe UI", Font.PLAIN, 14);

        // Panel principal de entrada
        JPanel panelEntrada = new JPanel();
        panelEntrada.setLayout(new BoxLayout(panelEntrada, BoxLayout.Y_AXIS));
        panelEntrada.setBackground(fondoFormulario);
        panelEntrada.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Panel formulario
        JPanel formulario = new JPanel(new GridLayout(9, 2, 10, 10));
        formulario.setOpaque(false);

        // Campos
        txtNombre = new JTextField(); txtNombre.setFont(campoFont);
        txtCedula = new JTextField(); txtCedula.setFont(campoFont);
        txtFechaNac = new JTextField(); txtFechaNac.setFont(campoFont);
        txtMonto = new JTextField(); txtMonto.setFont(campoFont);
        txtFechaInicio = new JTextField(); txtFechaInicio.setToolTipText("dd/MM/yyyy"); txtFechaInicio.setFont(campoFont);

        spnPlazo = new JSpinner(new SpinnerNumberModel(12, 3, 720, 1));
        spnPlazo.setFont(campoFont);

        cmbCredito = new JComboBox<>(new String[]{
            "Preciso (Consumo) - 15.6%", "Línea Abierta - 13%", 
            "Hipotecario Vivienda - 10.93%", "Vivienda VIP - 4.98%",
            "Vivienda VIS - 4.99%", "Educación Superior - 9.38%"
        });
        cmbCredito.setFont(campoFont);

        cmbMetodo = new JComboBox<>(new String[]{"Francés", "Alemán"});
        cmbMetodo.setFont(campoFont);

        // Etiquetas y campos
        formulario.add(crearEtiqueta("Nombres:", etiquetaFont));
        formulario.add(txtNombre);
        formulario.add(crearEtiqueta("Cédula:", etiquetaFont));
        formulario.add(txtCedula);
        formulario.add(crearEtiqueta("Fecha de Nacimiento (dd/MM/yyyy):", etiquetaFont));
        formulario.add(txtFechaNac);
        formulario.add(crearEtiqueta("Fecha de Inicio del Crédito (dd/MM/yyyy):", etiquetaFont));
        formulario.add(txtFechaInicio);
        formulario.add(crearEtiqueta("Monto:", etiquetaFont));
        formulario.add(txtMonto);
        formulario.add(crearEtiqueta("Plazo (meses):", etiquetaFont));
        formulario.add(spnPlazo);
        formulario.add(crearEtiqueta("Tipo de crédito:", etiquetaFont));
        formulario.add(cmbCredito);
        formulario.add(crearEtiqueta("Método de pago:", etiquetaFont));
        formulario.add(cmbMetodo);

        panelEntrada.add(formulario);

        // Botón
        JButton btnSimular = new JButton("SIMULAR CRÉDITO");
        btnSimular.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnSimular.setBackground(new Color(70, 130, 180));
        btnSimular.setForeground(Color.WHITE);
        btnSimular.setFocusPainted(false);
        btnSimular.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnSimular.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnSimular.setPreferredSize(new Dimension(200, 40));
        btnSimular.setMaximumSize(new Dimension(300, 40));
        btnSimular.setBorder(new EmptyBorder(10, 10, 10, 10));

        panelEntrada.add(Box.createVerticalStrut(10));
        panelEntrada.add(btnSimular);

        // Área de resultado
        txtResultado = new JTextArea();
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtResultado.setEditable(false);
        txtResultado.setBackground(new Color(245, 245, 245));
        txtResultado.setBorder(new TitledBorder("Resultado de Simulación"));

        JScrollPane scrollPane = new JScrollPane(txtResultado);
        scrollPane.setBorder(new EmptyBorder(10, 10, 10, 10));

        add(panelEntrada, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        btnSimular.addActionListener(e -> simularCredito());

        setVisible(true);
    }

    private JLabel crearEtiqueta(String texto, Font font) {
        JLabel label = new JLabel(texto);
        label.setFont(font);
        return label;
    }

    private void simularCredito() {
        try {
            String nombres = txtNombre.getText();
            String cedula = txtCedula.getText();
            String fechaNac = txtFechaNac.getText();
            String fechaInicioStr = txtFechaInicio.getText();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fechaInicio = LocalDate.parse(fechaInicioStr, formatter);

            double monto = Double.parseDouble(txtMonto.getText());
            int plazo = (Integer) spnPlazo.getValue();
            int metodo = cmbMetodo.getSelectedIndex() + 1;
            int tipoCredito = cmbCredito.getSelectedIndex() + 1;

            double tea = switch (tipoCredito) {
                case 1 -> 15.6; case 2 -> 13.0; case 3 -> 10.93;
                case 4 -> 4.98; case 5 -> 4.99; case 6 -> 9.38;
                default -> 0;
            };

            double tem = Math.pow(1 + tea / 100, 1.0 / 12) - 1;
            double saldo = monto;
            double valorCuota;

            StringBuilder sb = new StringBuilder();
            sb.append("***** DATOS DEL CLIENTE *****\n");
            sb.append(String.format("Cliente: %s\nCédula: %s\nFecha de Nacimiento: %s\n", nombres, cedula, fechaNac));
            sb.append(String.format("Fecha de inicio del crédito: %s\n", fechaInicio.format(formatter)));
            sb.append(String.format("Producto: %s\nMonto: $%.2f\nPlazo: %d meses\nTEA: %.2f%%\n",
                cmbCredito.getSelectedItem(), monto, plazo, tea));

            sb.append("\n***** TABLA DE AMORTIZACIÓN *****\n");
            sb.append("+-------+------------+-----------+-----------+-----------+-----------+-----------+-------------+\n");
            sb.append("| Cuota |   Fecha    |  Capital  |  Interés  | Seg.Desg. | Seg.Inc.  | Valor Tot |   Saldo     |\n");
            sb.append("+-------+------------+-----------+-----------+-----------+-----------+-----------+-------------+\n");

            for (int cuota = 1; cuota <= plazo; cuota++) {
                double interes = saldo * tem;
                double capital = (metodo == 1)
                        ? monto * (tem * Math.pow(1 + tem, plazo)) / (Math.pow(1 + tem, plazo) - 1) - interes
                        : monto / plazo;

                valorCuota = capital + interes;

                double segDesg = saldo * 0.0005;
                double segInc = (tipoCredito >= 3 && tipoCredito <= 5) ? saldo * 0.001 : 0;
                double total = valorCuota + segDesg + segInc;
                saldo -= capital;

                LocalDate fechaCuota = fechaInicio.plusMonths(cuota - 1);
                sb.append(String.format("| %5d | %10s | %9.2f | %9.2f | %9.2f | %9.2f | %9.2f | %11.2f |\n",
                        cuota, fechaCuota.format(formatter), capital, interes, segDesg, segInc, total, saldo));
            }

            txtResultado.setText(sb.toString());

        } catch (NumberFormatException | DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this,
                    "Verifica que todos los datos estén bien ingresados.\nFormato de fecha: dd/MM/yyyy",
                    "Error de ingreso", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); // Mejor apariencia nativa
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(SimuladorCredito1::new);
    }
}



