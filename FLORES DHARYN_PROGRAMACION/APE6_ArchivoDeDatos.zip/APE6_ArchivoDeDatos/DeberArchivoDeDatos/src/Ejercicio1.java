import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Ejercicio1 {
    public static void main(String[] args) {
        String archivo = "ProductosExportacion.csv";

        // 1.- Leer el archivo en una lista 
        System.out.println("1.- Leer el archivo en una lista ");
        List<Ejercicio2> lista = leerArchivo(archivo);
        System.out.println("Leídos " + lista.size() + " registros.\n");

        // 2.- escribir datos en el archivo  txt
        System.out.println("2.- escribir datos en el archivo  txt");
        escribirArchivo("exportaciones_salida.txt", lista);

        // 3.- obtener los montos de ventas de los países de centro america
        System.out.println("3.- obtener los montos de ventas de los países de centro america");
        obtenerMontosCentroAmerica(lista);

        // 4.-la sumatoria de pesos en toneladas por trimestre de los años 2022, 2023 y 2024
        System.out.println("4.-la sumatoria de pesos en toneladas por trimestre de los años 2022, 2023 y 2024");
        sumarPesosPorTrimestre(lista, Arrays.asList(2022, 2023, 2024));

        // 5.- por tipo de producto calcular la cantidad y el monto percibido de las exportaciones
        System.out.println("5.- por tipo de producto calcular la cantidad y el monto percibido de las exportaciones");
        calcularPorTipoProducto(lista);

        // 6.- porcentajes de los montos de exportaciones por año
        System.out.println("6.- porcentajes de los montos de exportaciones por año");
        calcularPorcentajesPorAnio(lista);
    }

    // Pregunta 1
    public static List<Ejercicio2> leerArchivo(String ruta) {
        List<Ejercicio2> lista = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea = br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length < 7) continue;
                Ejercicio2 p = new Ejercicio2(
                    Integer.parseInt(datos[0]), datos[1], Integer.parseInt(datos[2]), datos[3], datos[4], "",
                    Double.parseDouble(datos[5]), Double.parseDouble(datos[6])
                );
                lista.add(p);
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Pregunta 2
    public static void escribirArchivo(String ruta, List<Ejercicio2> lista) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (Ejercicio2 p : lista) {
                pw.println(p);
            }
            System.out.println("Archivo escrito...\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Pregunta 3
    public static void obtenerMontosCentroAmerica(List<Ejercicio2> lista) {
        Set<String> centroAmerica = Set.of("Nicaragua", "Honduras", "El Salvador", "Guatemala", "Panama", "Costa Rica");
        double total = 0;
        for (Ejercicio2 p : lista) {
            if (centroAmerica.contains(p.getPais())) {
                total += p.getMontoMillonesDolares();
            }
        }
        System.out.printf("Montos de ventas en Centroamérica: $%.2f millones\n\n", total);
    }

    // Pregunta 4
    public static void sumarPesosPorTrimestre(List<Ejercicio2> lista, List<Integer> anios) {
        Map<String, Double> acumulados = new TreeMap<>();
        for (Ejercicio2 p : lista) {
            if (anios.contains(p.getAnio())) {
                int trimestre = obtenerTrimestre(p.getMes());
                String clave = "Tonelada " + trimestre + " => " + p.getAnio();
                acumulados.put(clave, acumulados.getOrDefault(clave, 0.0) + p.getPesoToneladas());
            }
        }
        System.out.println("Sumatoria de pesos en toneladas:");
        for (String s : acumulados.keySet()) {
            System.out.printf("%s: %.2f toneladas\n", s, acumulados.get(s));
        }
        System.out.println();
    }

    public static int obtenerTrimestre(String mes) {
        mes = mes.toLowerCase();
        if (mes.contains("enero") || mes.contains("febrero") || mes.contains("marzo")) return 1;
        if (mes.contains("abril") || mes.contains("mayo") || mes.contains("junio")) return 2;
        if (mes.contains("julio") || mes.contains("agosto") || mes.contains("septiembre")) return 3;
        return 4;
    }

    // Pregunta 5
    public static void calcularPorTipoProducto(List<Ejercicio2> lista) {
        Map<String, Integer> conteo = new HashMap<>();
        Map<String, Double> montos = new HashMap<>();
        for (Ejercicio2 p : lista) {
            conteo.put(p.getTipoProducto(), conteo.getOrDefault(p.getTipoProducto(), 0) + 1);
            montos.put(p.getTipoProducto(), montos.getOrDefault(p.getTipoProducto(), 0.0) + p.getMontoMillonesDolares());
        }

        System.out.println("Cantidad y monto de exportaciones :");
        for (String tipo : conteo.keySet()) {
            System.out.printf("%s: %d exportaciones, $%.2f millones\n", tipo, conteo.get(tipo), montos.get(tipo));
        }
        System.out.println();
    }

    // Pregunta 6
    public static void calcularPorcentajesPorAnio(List<Ejercicio2> lista) {
        Map<Integer, Double> totalesPorAnio = new HashMap<>();
        double totalGeneral = 0;

        for (Ejercicio2 p : lista) {
            totalesPorAnio.put(p.getAnio(), totalesPorAnio.getOrDefault(p.getAnio(), 0.0) + p.getMontoMillonesDolares());
            totalGeneral += p.getMontoMillonesDolares();
        }

        System.out.println("Exportaciones por año:");
        for (Integer anio : totalesPorAnio.keySet()) {
            double porcentaje = (totalesPorAnio.get(anio) / totalGeneral) * 100;
            System.out.printf("%d => %.2f%%\n", anio, porcentaje);
        }
        System.out.println();
    }
}