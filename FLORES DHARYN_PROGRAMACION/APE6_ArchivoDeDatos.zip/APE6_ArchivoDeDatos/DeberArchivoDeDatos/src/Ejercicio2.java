public class Ejercicio2 {
    private int id;
    private String mes;
    private int anio;
    private String pais;
    private String tipoProducto;
    private String categoriaProducto;
    private double pesoToneladas;
    private double montoMillonesDolares;

    public Ejercicio2(int id, String mes, int anio, String pais, String tipoProducto,
                      String categoriaProducto, double pesoToneladas, double montoMillonesDolares) {
        this.id = id;
        this.mes = mes;
        this.anio = anio;
        this.pais = pais;
        this.tipoProducto = tipoProducto;
        this.categoriaProducto = categoriaProducto;
        this.pesoToneladas = pesoToneladas;
        this.montoMillonesDolares = montoMillonesDolares;
    }

    public int getId() { return id; }
    public String getMes() { return mes; }
    public int getAnio() { return anio; }
    public String getPais() { return pais; }
    public String getTipoProducto() { return tipoProducto; }
    public String getCategoriaProducto() { return categoriaProducto; }
    public double getPesoToneladas() { return pesoToneladas; }
    public double getMontoMillonesDolares() { return montoMillonesDolares; }

    public void setId(int id) { this.id = id; }
    public void setMes(String mes) { this.mes = mes; }
    public void setAnio(int anio) { this.anio = anio; }
    public void setPais(String pais) { this.pais = pais; }
    public void setTipoProducto(String tipoProducto) { this.tipoProducto = tipoProducto; }
    public void setCategoriaProducto(String categoriaProducto) { this.categoriaProducto = categoriaProducto; }
    public void setPesoToneladas(double pesoToneladas) { this.pesoToneladas = pesoToneladas; }
    public void setMontoMillonesDolares(double montoMillonesDolares) { this.montoMillonesDolares = montoMillonesDolares; }

    @Override
    public String toString() {
        return id + "\t" + mes + "\t" + anio + "\t" + pais + "\t" + tipoProducto + "\t" + pesoToneladas + "\t" + montoMillonesDolares;
    }

    public String ConvertirFormatoCSV() {
        return id + ";" + mes + ";" + anio + ";" + pais + ";" + tipoProducto + ";" + pesoToneladas + ";" + montoMillonesDolares + ";";
    }
}
