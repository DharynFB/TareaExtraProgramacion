import java.util.Scanner;

public class ejercicio8 {

    public static void CargarNotas(double[] notas) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < notas.length; i++) {
            do {
                System.out.print("Ingrese la nota " + (i + 1) + " (0 a 10): ");
                notas[i] = teclado.nextDouble();
            } while (notas[i] < 0 || notas[i] > 10);
        }
    }

    public static void ImprimirVectoresDoubles(double[] vector) {
        System.out.println("\nNotas ingresadas:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Nota " + (i + 1) + ": " + vector[i]);
        }
    }

    public static double CalcularPromedio(double[] vector) {
        double suma = 0;
        for (int i = 0; i < vector.length; i++) {
            suma += vector[i];
        }
        return suma / vector.length;
    }

    public static double DevolverMayor(double[] vector) {
        double mayor = vector[0];
        for (int i = 1; i < vector.length; i++) {
            if (vector[i] > mayor) {
                mayor = vector[i];
            }
        }
        return mayor;
    }

    public static double DevolverMenor(double[] vector) {
        double menor = vector[0];
        for (int i = 1; i < vector.length; i++) {
            if (vector[i] < menor) {
                menor = vector[i];
            }
        }
        return menor;
    }

    public static void main(String[] args) {
        double[] notas = new double[5];
        CargarNotas(notas);

        ImprimirVectoresDoubles(notas);

        double promedio = CalcularPromedio(notas);
        double mayor = DevolverMayor(notas);
        double menor = DevolverMenor(notas);

        System.out.printf("\nNota media: %.2f\n", promedio);
        System.out.println("Nota más alta: " + mayor);
        System.out.println("Nota más baja: " + menor);
    }
}
