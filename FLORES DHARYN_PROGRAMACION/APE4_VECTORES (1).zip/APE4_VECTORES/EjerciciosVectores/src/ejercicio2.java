import java.util.Scanner;

public class ejercicio2 {

    public static void CargarValoresEnVectorEntero(int[] vector) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese número " + (i + 1) + ": ");
            vector[i] = teclado.nextInt();
        }
    }

    public static int ContarMultiplosDeN(int[] vector, int n) {
        int contador = 0;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] % n == 0) {
                contador++;
            }
        }
        return contador;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[6];

        CargarValoresEnVectorEntero(numeros);

        System.out.print("Ingrese el valor de n para verificar múltiplos: ");
        int n = teclado.nextInt();

        int cantidadMultiplos = ContarMultiplosDeN(numeros, n);
        System.out.println("Cantidad de números múltiplos de " + n + ": " + cantidadMultiplos);

        teclado.close();
    }
}
