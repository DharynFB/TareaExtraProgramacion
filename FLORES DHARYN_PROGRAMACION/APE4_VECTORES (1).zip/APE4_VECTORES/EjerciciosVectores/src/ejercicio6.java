import java.util.Scanner;
public class ejercicio6 {
    public static void CargarMarcasDesdeTeclado(String[] coches, int desde) {
        Scanner teclado = new Scanner(System.in);
        for (int i = desde; i < coches.length; i++) {
            System.out.print("Ingrese la marca número " + (i + 1) + ": ");
            coches[i] = teclado.nextLine();
        }
    }
    public static void OrdenarVectorAlfabeticamente(String[] vector) {

        for (int i = 0; i < vector.length - 1; i++) {
            for (int j = 0; j < vector.length - 1 - i; j++) {
                if (vector[j].compareToIgnoreCase(vector[j + 1]) > 0) {
                    String temp = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = temp;
                }
            }
        }
    }
    public static void ImprimirVectoresString(String[] vector) {
        System.out.println("\nMarcas ordenadas alfabéticamente:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println((i + 1) + ". " + vector[i]);
        }
    }

    public static void main(String[] args) {
        String[] coches = new String[8];
        coches[0] = "Alfa Romeo";
        coches[1] = "Fiat";
        coches[2] = "Ford";
        coches[3] = "Lancia";
        coches[4] = "Renault";
        coches[5] = "Seat";
        CargarMarcasDesdeTeclado(coches, 6);
        OrdenarVectorAlfabeticamente(coches);
        ImprimirVectoresString(coches);
    }
}
