import java.util.Scanner;

public class ejercicio1 {

    public static void CargarValoresEnVectorEntero(int[] vector) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese número " + (i + 1) + ": ");
            vector[i] = teclado.nextInt();
        }

    }

    public static int DevolverSumaEnteros(int[] vector) {
        int suma = 0;
        for (int num : vector) {
            suma += num;
        }
        return suma;
    }

    public static double DevolverPromedioEnteros(int[] vector) {
        int suma = DevolverSumaEnteros(vector);
        return (double) suma / vector.length;
    }

    public static void main(String[] args) {
        int[] numeros = new int[4];
        int suma;
        double promedio;
        CargarValoresEnVectorEntero(numeros);

        suma = DevolverSumaEnteros(numeros);
        promedio = DevolverPromedioEnteros(numeros);

        System.out.println("Suma de los números: " + suma);
        System.out.printf("Promedio de los números: %.2f", promedio);
    }
}
