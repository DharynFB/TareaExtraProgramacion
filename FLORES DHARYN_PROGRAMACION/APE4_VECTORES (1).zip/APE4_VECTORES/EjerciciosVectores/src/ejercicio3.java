import java.util.Scanner;
public class ejercicio3 {
    public static void CargarValoresEnVectorEntero(int[] vector) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese número " + (i + 1) + ": ");
            vector[i] = teclado.nextInt();
        }
    }

    public static void ImprimirVectoresEnteros(int[] vector) {
        System.out.println("Contenido del vector:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println("numero " + i + ": " + vector[i]);
        }
    }

    public static void OrdenarVector(int[] vector, char orden) {
        if (orden == 'A' || orden == 'a') {
            OrdenarAscendente(vector);
        } else if (orden == 'D' || orden == 'd') {
            OrdenarDescendente(vector);
        } else {
            System.out.println("Opción no válida. No se realizó ningún ordenamiento.");
        }
    }

    public static void OrdenarAscendente(int[] vector) {
        for (int i = 0; i < vector.length - 1; i++) {
            for (int j = 0; j < vector.length - 1 - i; j++) {
                if (vector[j] > vector[j + 1]) {
                    int temp = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = temp;
                }
            }
        }
    }
    public static void OrdenarDescendente(int[] vector) {
        for (int i = 0; i < vector.length - 1; i++) {
            for (int j = 0; j < vector.length - 1 - i; j++) {
                if (vector[j] < vector[j + 1]) {
                    int temp = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = temp;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[5];
        char orden;
        CargarValoresEnVectorEntero(numeros);

        System.out.print("Ingrese 'A' para orden ascendente o 'D' para descendente: ");
        orden = teclado.next().charAt(0);

        OrdenarVector(numeros, orden);

        System.out.println("Vector ordenado:");
        ImprimirVectoresEnteros(numeros);
    }
}
