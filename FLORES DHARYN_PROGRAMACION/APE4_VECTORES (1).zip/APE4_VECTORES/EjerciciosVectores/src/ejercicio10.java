import java.util.Scanner;
public class ejercicio10 {

    public static void CargarValoresEnVectorEntero(int[] vector, String nombre) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese los valores para " + nombre + ":");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(nombre + "[" + i + "] = ");
            vector[i] = teclado.nextInt();
        }
    }

    public static void SumarVectores(int[] vector1, int[] vector2, int[] vector3) {
        for (int i = 0; i < vector1.length; i++) {
            vector3[i] = vector1[i] + vector2[i];
        }
    }

    public static void ImprimirVectoresEnteros(String nombre, int[] vector) {
        System.out.println(nombre + ":");
        for (int i = 0; i < vector.length; i++) {
            System.out.println(nombre + "[" + i + "] = " + vector[i]);
        }
    }

    public static void main(String[] args) {
        int[] vector1 = new int[5];
        int[] vector2 = new int[5];
        int[] vector3 = new int[5];

        CargarValoresEnVectorEntero(vector1, "vector1");
        CargarValoresEnVectorEntero(vector2, "vector2");

        SumarVectores(vector1, vector2, vector3);

        System.out.println("--- Resultado ---");
        ImprimirVectoresEnteros("vector1", vector1);
        ImprimirVectoresEnteros("vector2", vector2);
        ImprimirVectoresEnteros("vector3", vector3); 
    }
}
