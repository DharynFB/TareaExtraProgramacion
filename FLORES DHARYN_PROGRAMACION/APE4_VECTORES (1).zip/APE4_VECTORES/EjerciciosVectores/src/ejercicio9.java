import java.util.Random;
import java.util.Scanner;
public class ejercicio9 {
    public static void LlenarVectorConRandom(int[] vector, int limiteSuperior) {
        Random random = new Random();
        for (int i = 0; i < vector.length; i++) {
            vector[i] = random.nextInt(limiteSuperior + 1); 
        }
    }
    public static void ImprimirVectoresEnteros(int[] vector) {
        for (int i = 0; i < vector.length; i++) {
            System.out.println("numero " + (i + 1) + ": " + vector[i]);
        }
    }
    public static void OrdenarAscendente(int[] vector) {
        for (int i = 0; i < vector.length - 1; i++) {
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[i] > vector[j]) {
                    int temp = vector[i];
                    vector[i] = vector[j];
                    vector[j] = temp;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[10];

        System.out.print("Ingrese el límite superior para los valores aleatorios: ");
        int limite = teclado.nextInt();
        LlenarVectorConRandom(numeros, limite);
        System.out.println("\nValores aleatorios generados:");
        ImprimirVectoresEnteros(numeros);

        OrdenarAscendente(numeros);
        System.out.println("\nValores ordenados de menor a mayor:");
        ImprimirVectoresEnteros(numeros);
    }
}
