import java.util.Scanner;

public class ejercicio7 {

    public static void CargarVectoresString(String[] vector) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese el nombre " + (i + 1) + ": ");
            vector[i] = teclado.nextLine();
        }
    }

    public static void CopiarInverso(String[] original, String[] inverso) {
        for (int i = 0; i < original.length; i++) {
            inverso[i] = original[original.length - 1 - i];
        }
    }

    public static void ImprimirVectoresString(String[] vector) {
        System.out.println("Vector:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println((i + 1) + ". " + vector[i]);
        }
    }

    public static void main(String[] args) {
        String[] nombres = new String[5];
        String[] nombresInverso = new String[5];

        CargarVectoresString(nombres);
        CopiarInverso(nombres, nombresInverso);

        System.out.println("Vector original:");
        ImprimirVectoresString(nombres);

        System.out.println("Vector en orden inverso:");
        ImprimirVectoresString(nombresInverso);
    }
}
