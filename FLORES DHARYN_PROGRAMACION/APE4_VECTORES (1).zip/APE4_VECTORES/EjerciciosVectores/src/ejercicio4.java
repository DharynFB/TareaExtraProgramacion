import java.util.Scanner;

public class ejercicio4 {

    public static void CargarValoresEnVectorEntero(int[] vector) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese número " + (i + 1) + ": ");
            vector[i] = teclado.nextInt();
        }
    }

    public static int ContarRepetidos(int[] vector) {
        int contador = 0;
        boolean[] marcados = new boolean[vector.length];

        for (int i = 0; i < vector.length; i++) {
            if (!marcados[i]) {
                int repeticiones = 0;
                for (int j = i + 1; j < vector.length; j++) {
                    if (vector[i] == vector[j]) {
                        marcados[j] = true;
                        repeticiones++;
                    }
                }
                if (repeticiones > 0) {
                    contador++;
                }
            }
        }
        return contador;
    }

    public static void main(String[] args) {
        int[] numeros = new int[6];
        int repetidos;
        CargarValoresEnVectorEntero(numeros);
        repetidos = ContarRepetidos(numeros);
        System.out.println("Cantidad de números que se repiten: " + repetidos);
    }
}
