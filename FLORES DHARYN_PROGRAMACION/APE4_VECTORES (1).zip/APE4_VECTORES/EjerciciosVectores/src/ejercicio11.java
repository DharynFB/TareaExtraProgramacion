import java.util.Scanner;

public class ejercicio11 {

    public static void CargarNombresYEdades(String[] nombres, int[] edades) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < nombres.length; i++) {
            System.out.print("Ingrese el nombre del alumno (* para terminar): ");
            String nombre = teclado.nextLine();
            if (nombre.equals("*")) {
                nombres[i] = "*";
                break;
            }
            nombres[i] = nombre;

            System.out.print("Ingrese la edad de " + nombre + ": ");
            edades[i] = teclado.nextInt();
            teclado.nextLine(); // limpiar buffer
        }
    }

    public static void MostrarMayoresEdad(String[] nombres, int[] edades) {
        System.out.println("\nAlumnos mayores de edad:");
        boolean hayMayores = false;
        for (int i = 0; i < nombres.length; i++) {
            if (nombres[i] == null || nombres[i].equals("*")) break;
            if (edades[i] >= 18) {
                System.out.println(nombres[i] + " - " + edades[i] + " años");
                hayMayores = true;
            }
        }
        if (!hayMayores) {
            System.out.println("No hay alumnos mayores de edad.");
        }
    }

    public static void MostrarPromedioMenoresEdad(String[] nombres, int[] edades) {
        int suma = 0;
        int contador = 0;
        for (int i = 0; i < nombres.length; i++) {
            if (nombres[i] == null || nombres[i].equals("*")) break;
            if (edades[i] < 18) {
                suma += edades[i];
                contador++;
            }
        }
        if (contador > 0) {
            double promedio = (double) suma / contador;
            System.out.printf("\nPromedio de edad de alumnos menores de edad: %.2f\n", promedio);
        } else {
            System.out.println("\nNo hay alumnos menores de edad.");
        }
    }

    public static void main(String[] args) {
        final int TAM = 50; // capacidad máxima de alumnos
        String[] nombres = new String[TAM];
        int[] edades = new int[TAM];

        CargarNombresYEdades(nombres, edades);
        MostrarMayoresEdad(nombres, edades);
        MostrarPromedioMenoresEdad(nombres, edades);
    }
}
