import java.util.Scanner;
public class ejercicio12 {

    public static void CargarAlumnos(String[] nombres, int[] edades) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < nombres.length; i++) {
            System.out.print("Ingrese el nombre del alumno (* para terminar): ");
            String nombre = teclado.nextLine();
            if (nombre.equals("*")) {
                nombres[i] = "*";
                break;
            }
            nombres[i] = nombre;
            System.out.print("Ingrese la edad de " + nombre + ": ");
            edades[i] = teclado.nextInt();
            teclado.nextLine(); 
        }
    }
    public static void MostrarMayoresEdad(String[] nombres, int[] edades) {
        System.out.println("\nAlumnos mayores de edad:");
        boolean hayMayores = false;
        for (int i = 0; i < nombres.length; i++) {
            if (nombres[i] == null || nombres[i].equals("*")) break;

            if (edades[i] >= 18) {
                System.out.println(nombres[i] + " - " + edades[i] + " años");
                hayMayores = true;
            }
        }
        if (!hayMayores) {
            System.out.println("No hay alumnos mayores de edad.");
        }
    }
    public static void main(String[] args) {
        final int TAM = 50; 
        String[] nombres = new String[TAM];
        int[] edades = new int[TAM];
        CargarAlumnos(nombres, edades);
        MostrarMayoresEdad(nombres, edades);
    }
}
