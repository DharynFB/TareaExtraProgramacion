import java.util.Scanner;
public class ejercicio5 {

    public static void CargarPrimosSubsecuentes(int[] vector, int n) {
        int contador = 0;
        int candidato = n + 1;
        while (contador < vector.length) {
            if (EsPrimo(candidato)) {
                vector[contador] = candidato;
                contador++;
            }
            candidato++;
        }
    }

    public static boolean EsPrimo(int numero) {
        if (numero < 2) return false;
        for (int i = 2; i <= numero / 2; i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void ImprimirVectoresEnteros(int[] vector) {
        System.out.println("Números primos encontrados:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Primo " + (i + 1) + ": " + vector[i]);
        }
    }

    public static int DevolverSumaEnteros(int[] vector) {
        int suma = 0;
        for (int i = 0; i < vector.length; i++) {
            suma += vector[i];
        }
        return suma;
    }

    public static double DevolverPromedioEnteros(int[] vector) {
        int suma = DevolverSumaEnteros(vector);
        return (double) suma / vector.length;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese un número n: ");
        int n = teclado.nextInt();

        int[] primos = new int[10];
        CargarPrimosSubsecuentes(primos, n);
        ImprimirVectoresEnteros(primos);

        int suma = DevolverSumaEnteros(primos);
        double promedio = DevolverPromedioEnteros(primos);

        System.out.println("Suma de los primos: " + suma);
        System.out.printf("Promedio de los primos: %.2f\n", promedio);
    }
}
