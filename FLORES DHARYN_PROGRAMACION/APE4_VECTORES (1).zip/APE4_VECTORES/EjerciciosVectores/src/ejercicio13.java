import java.util.Scanner;

public class ejercicio13 {

    public static void CargarTemperaturas(double[] tempMin, double[] tempMax) {
        Scanner teclado = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese la temperatura mínima del día " + (i + 1) + ": ");
            tempMin[i] = teclado.nextDouble();
            System.out.print("Ingrese la temperatura máxima del día " + (i + 1) + ": ");
            tempMax[i] = teclado.nextDouble();
        }
    }

    public static void CalcularMostrarPromedios(double[] tempMin, double[] tempMax, double[] tempMedia) {
        System.out.println("Temperatura promedio de cada día:");
        for (int i = 0; i < 5; i++) {
            tempMedia[i] = (tempMin[i] + tempMax[i]) / 2;
            System.out.printf("Día %d: %.2f°C\n", (i + 1), tempMedia[i]);
        }
    }

    public static int ObtenerDiaConPromedioMasBajo(double[] tempMedia) {
        int diaMin = 0;
        for (int i = 1; i < tempMedia.length; i++) {
            if (tempMedia[i] < tempMedia[diaMin]) {
                diaMin = i;
            }
        }
        return diaMin;
    }

    public static int ObtenerDiaConPromedioMasAlto(double[] tempMedia) {
        int diaMax = 0;
        for (int i = 1; i < tempMedia.length; i++) {
            if (tempMedia[i] > tempMedia[diaMax]) {
                diaMax = i;
            }
        }
        return diaMax;
    }

    public static void main(String[] args) {
        double[] temperaturasMin = new double[5];
        double[] temperaturasMax = new double[5];
        double[] temperaturasMedia = new double[5];
        int diaMin;
        int diaMax;     
        CargarTemperaturas(temperaturasMin, temperaturasMax);
        CalcularMostrarPromedios(temperaturasMin, temperaturasMax, temperaturasMedia);

        diaMin = ObtenerDiaConPromedioMasBajo(temperaturasMedia);
        diaMax = ObtenerDiaConPromedioMasAlto(temperaturasMedia);

        System.out.printf("Día con promedio de temperatura más baja: Día %d (%.2f°C)", diaMin + 1, temperaturasMedia[diaMin]);
        System.out.println(" ");
        System.out.printf("Día con promedio de temperatura más alta: Día %d (%.2f°C)", diaMax + 1, temperaturasMedia[diaMax]);
    }
}
