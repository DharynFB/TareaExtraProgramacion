public class Ejercicio8 {
    public static void main(String[] args) {
        // Coeficientes
        double a1 = 7, b1 = 4, c1 = 13;
        double a2 = 5, b2 = -2, c2 = 19;

        // Determinantes
        double D  = a1 * b2 - a2 * b1;
        double Dx = c1 * b2 - c2 * b1;
        double Dy = a1 * c2 - a2 * c1;

        System.out.println("Sistema de ecuaciones:");
        System.out.println(a1 + "x + " + b1 + "y = " + c1);
        System.out.println(a2 + "x + " + b2 + "y = " + c2);

        if (D == 0) {
            System.out.println("\nEl sistema no tiene solución única (D=0)");
        } else {
            double x = Dx / D;
            double y = Dy / D;

            System.out.println("\nSolución usando el método de Cramer:");
            System.out.printf("x = %.2f\n", x);
            System.out.printf("y = %.2f\n", y);
        }
    }
}
