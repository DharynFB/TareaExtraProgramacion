public class Ejercicio6 {
    public static void main(String[] args) {
        // Matriz: filas = facultades (4), columnas = materias (5)
        int[][] asistencia = {
            {120, 110, 130, 140, 125}, // Facultad 1
            {115, 98, 105, 120, 110},  // Facultad 2
            {140, 135, 128, 132, 145}, // Facultad 3
            {100, 105, 98, 115, 120}   // Facultad 4
        };

        int[] asistenciaMateria = new int[5];
        int[] totalFacultades = new int[4];
        int asistenciaTotal = 0;
        int facultadMayorAsistencia = 0;
        int mayorAsistencia = 0;

        // Ítem 1: Asistencia total por materia
        System.out.println("Ítem N°1");
        System.out.println("Asistencia total por materia:");
        for (int m = 0; m < asistencia[0].length; m++) {
            int suma = 0;
            for (int f = 0; f < asistencia.length; f++) {
                suma += asistencia[f][m];
            }
            asistenciaMateria[m] = suma;
            asistenciaTotal += suma;
            System.out.println("Materia " + (m + 1) + ": " + suma + " alumnos");
        }

        // Ítem 2: Asistencia total en la facultad 3
        System.out.println("\nÍtem N°2");
        int totalFacultad3 = 0;
        for (int m = 0; m < asistencia[0].length; m++) {
            totalFacultad3 += asistencia[2][m];
        }
        System.out.println("Asistencia total en la Facultad 3: " + totalFacultad3 + " alumnos");

        // Ítem 3: Asistencia en la materia 2 de la facultad 1
        System.out.println("\nÍtem N°3");
        System.out.println("Asistencia en la Materia 2 de la Facultad 1: " + asistencia[0][1] + " alumnos");

        // Ítem 4: Porcentaje de asistencia por facultad
        System.out.println("\nÍtem N°4");
        System.out.println("Porcentaje de asistencia por facultad:");
        for (int f = 0; f < asistencia.length; f++) {
            int suma = 0;
            for (int m = 0; m < asistencia[0].length; m++) {
                suma += asistencia[f][m];
            }
            totalFacultades[f] = suma;
            double porcentaje = (suma * 100.0) / asistenciaTotal;
            System.out.printf("Facultad %d: %.2f%%\n", (f + 1), porcentaje);
        }

        // Ítem 5: Facultad con mayor asistencia
        System.out.println("\nÍtem N°5");
        for (int f = 0; f < totalFacultades.length; f++) {
            if (totalFacultades[f] > mayorAsistencia) {
                mayorAsistencia = totalFacultades[f];
                facultadMayorAsistencia = f;
            }
        }
        System.out.println("La facultad con mayor asistencia es la Facultad " +
                           (facultadMayorAsistencia + 1) + " con " + mayorAsistencia + " alumnos.");
    }
}
