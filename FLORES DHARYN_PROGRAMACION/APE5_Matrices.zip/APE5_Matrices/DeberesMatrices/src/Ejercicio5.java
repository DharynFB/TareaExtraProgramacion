public class Ejercicio5 {
    public static void main(String[] args) {
        int[][] stock = {
            {20, 35, 15, 40, 22, 30, 25, 10}, // Almacén 1
            {12, 18, 10, 25, 30, 15, 20, 8},  // Almacén 2
            {17, 20, 12, 30, 25, 22, 18, 14}  // Almacén 3
        };

        int[] precios = {100, 200, 50, 40, 80, 100, 60, 50};
        int[] inventarioProductos = new int[8];
        int[] totalPorAlmacen = new int[3];
        int mayorInventario = 0;
        int almacenMayor = 0;

        // Ítem 1: Mostrar inventario total de cada producto
        System.out.println("Ítem N°1");
        System.out.println("Inventario total por producto:");
        for (int p = 0; p < stock[0].length; p++) {
            int suma = 0;
            for (int a = 0; a < stock.length; a++) {
                suma += stock[a][p];
            }
            inventarioProductos[p] = suma;
            System.out.println("Producto " + (p + 1) + ": " + suma + " unidades");
        }

        // Ítem 2: Inventario total del almacén 1
        System.out.println("\nÍtem N°2");
        int totalAlmacen1 = 0;
        for (int p = 0; p < stock[0].length; p++) {
            totalAlmacen1 += stock[0][p];
        }
        System.out.println("Inventario total del Almacén 1: " + totalAlmacen1 + " unidades");

        // Ítem 3: Stock del producto 4 en el almacén 2
        System.out.println("\nÍtem N°3");
        System.out.println("Stock del producto 4 en el Almacén 2: " + stock[1][3] + " unidades");

        // Ítem 4: Valor total del inventario
        System.out.println("\nÍtem N°4");
        int valorTotal = 0;
        for (int a = 0; a < stock.length; a++) {
            for (int p = 0; p < stock[0].length; p++) {
                valorTotal += stock[a][p] * precios[p];
            }
        }
        System.out.println("Valor total del inventario de la cadena: $" + valorTotal);

        // Ítem 5: Almacén con mayor cantidad de productos
        System.out.println("\nÍtem N°5");
        for (int a = 0; a < stock.length; a++) {
            int suma = 0;
            for (int p = 0; p < stock[0].length; p++) {
                suma += stock[a][p];
            }
            totalPorAlmacen[a] = suma;

            if (suma > mayorInventario) {
                mayorInventario = suma;
                almacenMayor = a;
            }
        }
        System.out.println("El almacén con mayor cantidad de productos es el Almacén " + (almacenMayor + 1) +
                           " con " + mayorInventario + " unidades.");
    }
}
