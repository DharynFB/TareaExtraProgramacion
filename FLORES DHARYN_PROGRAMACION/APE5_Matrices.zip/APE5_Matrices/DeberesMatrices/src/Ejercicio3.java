public class Ejercicio3 {
    public static void main(String[] args) {
        int[][] marco = new int[5][15];

        // Ítem 1: Cargar la matriz con 1 en los bordes y 0 en el interior
        System.out.println("Ítem N°1");
        System.out.println("Cargando matriz con 1 en los bordes y 0 en el interior");
        for (int f = 0; f < marco.length; f++) {
            for (int c = 0; c < marco[0].length; c++) {
                if (f == 0 || f == marco.length - 1 || c == 0 || c == marco[0].length - 1) {
                    marco[f][c] = 1;
                } else {
                    marco[f][c] = 0;
                }
            }
        }

        // Ítem 2: Mostrar la matriz
        System.out.println("\nÍtem N°2");
        System.out.println("Contenido de la matriz:");
        for (int f = 0; f < marco.length; f++) {
            for (int c = 0; c < marco[0].length; c++) {
                System.out.print(marco[f][c]);
            }
            System.out.println();
        }
    }
}
