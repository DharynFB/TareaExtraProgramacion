public class Ejercicio7 {
    public static void main(String[] args) {
        int n = 3; // Tamaño de la matriz nxn
        int[][] matrizA = {
            {2, 4, 1},
            {3, 5, 7},
            {6, 8, 9}
        };

        int[][] matrizB = {
            {1, 0, 2},
            {4, 3, 5},
            {7, 6, 8}
        };

        int[][] suma = new int[n][n];
        int[][] producto = new int[n][n];
        int sumaTotal = 0;
        int totalElementos = n * n * 2;
        int mayorElementoSuma = Integer.MIN_VALUE;

        // Calcular suma de matrices y total para promedio
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                suma[i][j] = matrizA[i][j] + matrizB[i][j];
                sumaTotal += matrizA[i][j] + matrizB[i][j];
                if (suma[i][j] > mayorElementoSuma) {
                    mayorElementoSuma = suma[i][j];
                }
            }
        }

        // Mostrar suma de matrices
        System.out.println("Suma de las dos matrices:");
        imprimirMatriz(suma);

        // Mostrar promedio
        double promedio = (double) sumaTotal / totalElementos;
        System.out.printf("\nPromedio de todos los elementos: %.2f\n", promedio);

        // Calcular multiplicación de matrices
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                producto[i][j] = 0;
                for (int k = 0; k < n; k++) {
                    producto[i][j] += matrizA[i][k] * matrizB[k][j];
                }
            }
        }

        // Mostrar producto de matrices
        System.out.println("\nProducto de las dos matrices:");
        imprimirMatriz(producto);

        // Mostrar mayor elemento de la suma
        System.out.println("\nElemento mayor de la matriz suma: " + mayorElementoSuma);
    }

    public static void imprimirMatriz(int[][] matriz) {
        for (int[] fila : matriz) {
            for (int val : fila) {
                System.out.print(val + "\t");
            }
            System.out.println();
        }
    }
}
