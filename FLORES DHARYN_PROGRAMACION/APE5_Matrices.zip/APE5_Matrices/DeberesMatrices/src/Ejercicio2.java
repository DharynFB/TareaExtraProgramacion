public class Ejercicio2 {
    public static void main(String[] args) {
        int[][] diagonal = new int[5][5];

        // Ítem 1: Cargar la matriz con 1 en la diagonal y 0 en el resto
        System.out.println("ítem N°1");
        System.out.println("Cargando matriz con 1 en la diagonal y 0 en el resto");
        for (int f = 0; f < diagonal.length; f++) {
            for (int c = 0; c < diagonal[0].length; c++) {
                if (f == c) {
                    diagonal[f][c] = 1;
                } else {
                    diagonal[f][c] = 0;
                }
            }
        }

        // Ítem 2: Mostrar la matriz
        System.out.println("\nÍtem N°2");
        System.out.println("Contenido de la matriz:");
        for (int f = 0; f < diagonal.length; f++) {
            for (int c = 0; c < diagonal[0].length; c++) {
                System.out.print(diagonal[f][c] + "\t");
            }
            System.out.println();
        }
    }
}
