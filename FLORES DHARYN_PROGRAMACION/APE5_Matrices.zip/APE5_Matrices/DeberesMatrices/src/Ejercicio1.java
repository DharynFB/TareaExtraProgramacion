public class Ejercicio1 {
    public static void main(String[] args) {
        int[][] matriz = {
            {4, 2, 7, 1, 3},
            {6, 5, 2, 9, 8},
            {1, 0, 3, 5, 7},
            {9, 8, 6, 4, 2},
            {3, 1, 4, 6, 0}
        };
        int sumaFila, sumaColumna;
        // Ítem 1: Mostrar la matriz original
        System.out.println("Ítem N°1");
        System.out.println("Contenido de la matriz:");
        for (int f = 0; f < matriz.length; f++) {
            for (int c = 0; c < matriz[0].length; c++) {
                System.out.print(matriz[f][c] + "\t");
            }
            System.out.println();
        }
        // Ítem 2: Suma de cada fila
        System.out.println("\nÍtem N°2");
        System.out.println("Suma de los elementos de cada fila:");
        for (int f = 0; f < matriz.length; f++) {
            sumaFila = 0;
            for (int c = 0; c < matriz[0].length; c++) {
                sumaFila += matriz[f][c];
            }
            System.out.println("Fila " + (f + 1) + " = " + sumaFila);
        }
        // Ítem 3: Suma de cada columna
        System.out.println("\nÍtem N°3");
        System.out.println("Suma de los elementos de cada columna:");
        for (int c = 0; c < matriz[0].length; c++) {
            sumaColumna = 0;
            for (int f = 0; f < matriz.length; f++) {
                sumaColumna += matriz[f][c];
            }
            System.out.println("Columna " + (c + 1) + " = " + sumaColumna);
        }
    }
}
