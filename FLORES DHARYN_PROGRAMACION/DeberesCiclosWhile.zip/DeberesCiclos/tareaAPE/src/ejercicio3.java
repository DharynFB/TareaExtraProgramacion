import java.util.Scanner;

public class ejercicio3 {
    public static void main(String[] args) {
        // Declaración de variables
        int numero, numeroOriginal, numeroAbsoluto, inverso, digito;

        // Inicialización de Scanner
        Scanner teclado = new Scanner(System.in);

        // Solicitar al usuario un número entero
        System.out.print("Ingresa un número entero: ");
        numero = teclado.nextInt();

        // Inicialización de variables
        numeroOriginal = numero;
        numeroAbsoluto = Math.abs(numero);
        inverso = 0;

        // Invertir el número usando ciclo while
        while (numeroAbsoluto > 0) {
            digito = numeroAbsoluto % 10;           // Tomar el último dígito
            inverso = inverso * 10 + digito;        // Agregarlo al inverso
            numeroAbsoluto = numeroAbsoluto / 10;   // Eliminar el último dígito
        }

        // Si el número original era negativo, el inverso también debe serlo
        if (numero < 0) {
            inverso = -inverso;
        }

        // Mostrar el resultado
        System.out.println("El inverso de " + numeroOriginal + " es: " + inverso);

    }
}

