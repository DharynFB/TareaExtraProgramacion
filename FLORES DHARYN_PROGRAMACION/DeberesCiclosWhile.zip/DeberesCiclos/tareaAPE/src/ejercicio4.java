import java.util.Scanner;

public class ejercicio4 {
    public static void main(String[] args) {
        // Declarar variables
        int numeroDecimal, baseDestino, numeroOriginal, residuo;
        String resultado;
        boolean baseValida;

        // Inicializar scanner y variables 
        Scanner teclado = new Scanner(System.in);
        resultado = "";
        baseValida = false;
        numeroDecimal = 0;
        baseDestino = 0;
        numeroOriginal = 0;
        residuo = 0;
        // Solicitar el número decimal
        System.out.print("Ingresa un número entero en base 10: ");
        numeroDecimal = teclado.nextInt();
        numeroOriginal = numeroDecimal;
        // Validar la base destino (debe ser entre 2 y 9)
        while (!baseValida) {
            System.out.print("Ingresa la base destino (entre 2 y 9): ");
            baseDestino = teclado.nextInt();

            if (baseDestino >= 2 && baseDestino <= 9) {
                baseValida = true;
            } else {
                System.out.println("Base inválida,intenta de nuevo.");
            }
        }
        // Conversión del número
        if (numeroDecimal == 0) {
            resultado = "0";
        } else {
            while (numeroDecimal > 0) {
                residuo = numeroDecimal % baseDestino;             
                resultado = residuo + resultado;                   
                numeroDecimal = numeroDecimal / baseDestino;       
            }
        }
        //resultado
        System.out.println("El número " + numeroOriginal + " en base " + baseDestino + " es: " + resultado);
    }
}

