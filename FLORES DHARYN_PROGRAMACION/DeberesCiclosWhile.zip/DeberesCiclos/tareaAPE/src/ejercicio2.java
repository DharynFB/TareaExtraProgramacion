import java.util.Scanner;

public class ejercicio2 {
    public static void main(String[] args) {
        // inicializar scanner
        Scanner teclado = new Scanner(System.in);
        //declarar variables
        int inicio,fin,temp,actual,totalPares,numero,digito;
        // Solicitar al usuario el número de inicio del rango
        System.out.print("Ingresa el número de inicio del rango: ");
        inicio = teclado.nextInt();

        // Solicitar al usuario el número de fin del rango
        System.out.print("Ingresa el número de fin del rango: ");
        fin = teclado.nextInt();

        // Asegurarse de que el rango esté en orden correcto (inicio <= fin)
        if (inicio > fin) {
            // Intercambiar si el usuario los ingresó al revés
            temp = inicio;
            inicio = fin;
            fin = temp;
        }

        actual = inicio;       // Número actual en el recorrido del rango
        totalPares = 0;        // Contador de dígitos pares en total

        // Recorrer todos los números del rango
        while (actual <= fin) {
            numero = Math.abs(actual); // Trabajar con valor absoluto

            // Contar los dígitos pares de este número
            while (numero > 0) {
                digito = numero % 10; // Obtener último dígito

                if (digito % 2 == 0) {
                    totalPares++;         // Si es par, aumentamos el contador
                }

                numero = numero / 10;     // Eliminar último dígito
            }

            actual++; // Pasar al siguiente número del rango
        }

        //resultado final
        System.out.println("Cantidad total de dígitos pares en el rango: " + totalPares);
    }
}

