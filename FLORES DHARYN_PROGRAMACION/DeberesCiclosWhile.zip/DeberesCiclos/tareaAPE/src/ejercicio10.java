import java.util.Scanner;

public class ejercicio10 {
    public static void main(String[] args) {
        // Declaración de variables
        int numero, base, digito;
        boolean perteneceABase;

        // Inicialización de variables
        Scanner teclado = new Scanner(System.in);
        perteneceABase = true;  // Inicialmente asumimos que el número pertenece a la base

        // Solicitar al usuario el número y la base
        System.out.print("Ingresa el número: ");
        numero = teclado.nextInt();
        
        System.out.print("Ingresa la base: ");
        base = teclado.nextInt();

        // Verificar si el número pertenece a la base usando un ciclo do-while
        do {
            digito = numero % 10;  // Obtener el último dígito
            if (digito >= base) {
                perteneceABase = false;  // Si algún dígito es mayor o igual a la base, no pertenece
            }
            numero = numero / 10;  
        } while (numero > 0); 

        // resultado
        if (perteneceABase) {
            System.out.println("El número pertenece a la base " + base + ".");
        } else {
            System.out.println("El número NO pertenece a la base " + base + ".");
        }
    }
}
