import java.util.Scanner;

public class ejercicio11 {
    public static void main(String[] args) {
        // Declarar variables
        int inicio, fin, actual, contadorPrimos, i, divisor;
        boolean esPrimo;

        // Inicializar
        Scanner teclado = new Scanner(System.in);
        contadorPrimos = 0;

        // Solicitar el rango al usuario
        System.out.print("Ingresa el número de inicio del rango: ");
        inicio = teclado.nextInt();

        System.out.print("Ingresa el número final del rango: ");
        fin = teclado.nextInt();
        // Ajustar el inicio si es menor que 2 (pues no hay primos menores que 2)
        if (inicio < 2) {
            inicio = 2;
        }

        // Comenzar desde el número inicial
        actual = inicio;

        do {
            esPrimo = true;

            // Verificar si el número es primo
            divisor = 2;
            while (divisor <= Math.sqrt(actual)) {
                if (actual % divisor == 0) {
                    esPrimo = false;
                    break;
                }
                divisor++;
            }
            // Si es primo, incrementar el contador
            if (esPrimo) {
                contadorPrimos++;
            }
            actual++; // Avanzar al siguiente número
        } while (actual <= fin); // Continuar hasta el número final

        //resultado
        System.out.println("Cantidad de números primos: " + contadorPrimos);
    }
}

