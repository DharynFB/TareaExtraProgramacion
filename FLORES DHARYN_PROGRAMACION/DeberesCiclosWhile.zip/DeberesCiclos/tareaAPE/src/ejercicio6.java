import java.util.Scanner;

public class ejercicio6 {
    public static void main(String[] args) {
        // Declarar variables
        int a, b, dividendo, divisor, residuo, mcd;

        // Inicializar scanner
        Scanner teclado = new Scanner(System.in);

        // Solicitar los dos números al usuario
        System.out.print("Ingresa el primer número: ");
        a = teclado.nextInt();

        System.out.print("Ingresa el segundo número: ");
        b = teclado.nextInt();

        // Tomar valores absolutos para evitar problemas con negativos
        dividendo = Math.abs(a);
        divisor = Math.abs(b);
        residuo = 0;
        mcd = 0;

        // Aplicar el algoritmo de Euclides (divisiones sucesivas)
        while (divisor != 0) {
            residuo = dividendo % divisor;
            dividendo = divisor;
            divisor = residuo;
        }

        // El MCD es el último divisor distinto de cero
        mcd = dividendo;

        // Mostrar el resultado
        System.out.println("El MCD de " + a + " y " + b + " es: " + mcd);
    }
}
