import java.util.Scanner;

public class ejercicio9 {
    public static void main(String[] args) {
        // Declaración de variables
        int num1, num2, sumaDivisoresNum1, sumaDivisoresNum2;
        int i;

        // Inicializar
        Scanner teclado = new Scanner(System.in);
        sumaDivisoresNum1 = 0;
        sumaDivisoresNum2 = 0;

        // Solicitar los dos números al usuario
        System.out.print("Ingresa el primer número: ");
        num1 = teclado.nextInt();

        System.out.print("Ingresa el segundo número: ");
        num2 = teclado.nextInt();

        // Calcular la suma de los divisores de num1 usando do-while
        i = 1;
        do {
            if (num1 % i == 0) {
                sumaDivisoresNum1 += i;
            }
            i++;
        } while (i <= num1 / 2);

        // Calcular la suma de los divisores de num2 usando do-while
        i = 1;
        do {
            if (num2 % i == 0) {
                sumaDivisoresNum2 += i;
            }
            i++;
        } while (i <= num2 / 2);

        // Verificar si los números son amigos
        if (sumaDivisoresNum1 == num2 && sumaDivisoresNum2 == num1) {
            System.out.println(num1 + " y " + num2 + " son números amigos.");
        } else {
            System.out.println(num1 + " y " + num2 + " NO son números amigos.");
        }
    }
}

