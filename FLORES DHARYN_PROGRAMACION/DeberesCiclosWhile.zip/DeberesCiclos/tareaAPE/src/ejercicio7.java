import java.util.Scanner;

public class ejercicio7 {
    public static void main(String[] args) {
        // Declarar variables
        int N, contador, numero, multiplo;

        // Inicializar
        Scanner teclado= new Scanner(System.in);
        N = 0;
        contador = 0;
        numero = 1;
        multiplo = 0;

        // Solicitar al usuario cuántos múltiplos de 5 quiere obtener
        System.out.print("Ingresa la cantidad de múltiplos de 5 que deseas: ");
        N = teclado.nextInt();

        System.out.println("Primeros " + N + " múltiplos de 5:");

        // realizar múltiplos de 5 
        do {
            if (numero % 5 == 0) {
                System.out.println(numero); 
                contador++;                 
            }
            numero++; 
        } while (contador < N);

    }
}
