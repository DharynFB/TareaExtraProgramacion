import java.util.Scanner;

public class ejercicio5 {
    public static void main(String[] args) {
        // Declarar variables
        int numero, digitoBuscado, digitoActual, numeroAbsoluto;
        boolean encontrado;

        // Inicialización de variables y scanner
        Scanner teclado = new Scanner(System.in);
        numero = 0;
        digitoBuscado = 0;
        digitoActual = 0;
        numeroAbsoluto = 0;
        encontrado = false;

        // Solicitar número entero al usuario
        System.out.print("Ingresa un número entero: ");
        numero = teclado.nextInt();

        // Solicitar el dígito que se desea buscar
        System.out.print("Ingresa el dígito a buscar (0-9): ");
        digitoBuscado = teclado.nextInt();

        // Validar que el dígito esté en el rango correcto
        if (digitoBuscado < 0 || digitoBuscado > 9) {
            System.out.println("Dígito inválido, debe estar entre 0 y 9.");
        } else {
            // Tomamos el valor absoluto del número para evitar problemas con negativos
            numeroAbsoluto = Math.abs(numero);

            // Buscar el dígito usando un ciclo while
            while (numeroAbsoluto > 0 && !encontrado) {
                digitoActual = numeroAbsoluto % 10;          // Obtener último dígito
                if (digitoActual == digitoBuscado) {
                    encontrado = true;                       // Dígito encontrado
                }
                numeroAbsoluto = numeroAbsoluto / 10;        // Eliminar último dígito
            }

            //resultado
            if (encontrado) {
                System.out.println("El dígito " + digitoBuscado + " SÍ está en el número " + numero + ".");
            } else {
                System.out.println("El dígito " + digitoBuscado + " NO está en el número " + numero + ".");
            }
        }
    }
}
