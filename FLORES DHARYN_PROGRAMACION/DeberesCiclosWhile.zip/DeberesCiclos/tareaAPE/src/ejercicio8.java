import java.util.Scanner;

public class ejercicio8 {
    public static void main(String[] args) {
        // Declarar variables
        int numero, digito, digitoMayor;

        // Inicializar
        Scanner teclado= new Scanner(System.in);
        numero = 0;
        digitoMayor = -1;

        // Solicitar un número 
        System.out.print("Ingresa un número: ");
        numero = teclado.nextInt();

        // Tomar el valor absoluto del número para evitar problemas con negativos
        numero = Math.abs(numero);

        // Verificar si el número es 0
        if (numero == 0) {
            digitoMayor = 0;
        } else {
            // Recorrer cada dígito del número
            while (numero > 0) {
                digito = numero % 10;         // Obtener el último dígito
                if (digito > digitoMayor) {
                    digitoMayor = digito;     // Actualizar el dígito mayor
                }
                numero = numero / 10;         // Eliminar el último dígito
            }
        }

        // Mostrar el dígito mayor
        System.out.println("El dígito mayor es: " + digitoMayor);

    
    }
}
