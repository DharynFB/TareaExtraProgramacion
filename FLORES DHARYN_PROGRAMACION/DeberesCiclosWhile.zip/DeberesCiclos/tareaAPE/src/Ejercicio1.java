import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        // inicializar scanner 
        Scanner scanner = new Scanner(System.in);
        //declarar variables
        int inicio,fin,contador = 0,actual;
        // Pedir al usuario el número de inicio del rango
        System.out.print("Ingresa el número de inicio del rango: ");
        inicio = scanner.nextInt();

        // Pedir al usuario el número de fin del rango
        System.out.print("Ingresa el número de fin del rango: ");
        fin = scanner.nextInt();

        // Variable auxiliar para recorrer el rango
        actual = inicio;

        // Usamos un ciclo while para contar cuántos números hay entre inicio y fin
        while (actual <= fin) {
            contador++;   // Contamos este número
            actual++;     // Pasamos al siguiente número
        }

        // Mostramos el resultado
        System.out.println("Cantidad de números enteros en el rango: " + contador);
    }
}
