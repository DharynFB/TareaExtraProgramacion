import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        //declarar variables 
        char seleccionOp;
        double r, n1, n2;
        Scanner t = new Scanner(System.in);
        //pedir al usuario que ingrese la operacion que desee realizar 
        System.out.println("Escoja una operación: ");
        System.out.println(" (+)suma -- (-)resta -- (*)multiplicación -- (/)división");
        seleccionOp = t.next().charAt(0);
        //condicional para saber cual es la operacion a realizar
        if (seleccionOp == '+') {
            System.out.println("Ingrese el número 1: ");
            n1 = t.nextFloat();
            System.out.println("Ingrese el número 2: ");
            n2 = t.nextFloat();
            r = n1 + n2;
            System.out.println(n1 + " + " + n2 + " = " + r);
        } else if (seleccionOp == '-') {
            System.out.println("Ingrese el número 1: ");
            n1 = t.nextFloat();
            System.out.println("Ingrese el número 2: ");
            n2 = t.nextFloat();
            r = n1 - n2;
            System.out.println(n1 + " - " + n2 + " = " + r);
        } else if (seleccionOp == '*') {
            System.out.println("Ingrese el multiplicando: ");
            n1 = t.nextFloat();
            System.out.println("Ingrese el multiplicador: ");
            n2 = t.nextFloat();
            r = n1 * n2;
            System.out.println(n1 + " * " + n2 + " = " + r);
        } else if (seleccionOp == '/') {
            System.out.println("Ingrese el dividendo: ");
            n1 = t.nextFloat();
            System.out.println("Ingrese el divisor: ");
            n2 = t.nextFloat();
            if (n2 != 0) {
                r = n1 / n2;
                System.out.println(n1 + " / " + n2 + " = " + r);
            } else {
                System.out.println("la división por cero no es permitida.");
            }
        } else {
            System.out.println("la operacion ingresada no se encuentra");
        }

       
    }
}
