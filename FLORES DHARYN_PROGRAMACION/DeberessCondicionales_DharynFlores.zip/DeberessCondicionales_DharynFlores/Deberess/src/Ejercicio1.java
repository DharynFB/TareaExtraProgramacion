import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
     
        //DECLARACION DE VARIABLES
        float n1,n2,n3;
        
        Scanner t= new Scanner(System.in);
        //pedir al usuario que ingrese los numeros 
        System.out.println("Escriba el primer numero: ");
        n1= t.nextFloat();
        
        System.out.println("Escriba el segundo numero: ");
        n2= t.nextFloat();
        
        System.out.println("Escriba el tercer numero: ");
        n3= t.nextFloat();
        // proceso para determinar si el numero se encuentra en la mitad 

        if (n1>n2 && n1<n3) {
            System.out.println("el numero de la mitad es: " + n1);
        }
        if (n2>n1 && n2<n3) {
            System.out.println("el numero de la mitad es: "+ n2);
        }
        if (n3>n1 && n3<n2) {
            System.out.println("el numero de la mitad es: "+ n3);
        }
            

        
    }
}
