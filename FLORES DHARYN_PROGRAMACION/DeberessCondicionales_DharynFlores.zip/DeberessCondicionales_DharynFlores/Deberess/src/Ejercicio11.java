
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
        //declarar variables 
        Float monto, descuento;
         Scanner t= new Scanner(System.in);
         //pedir al usuario que ingrese el valor de compra
         System.out.println("Ingrese el valor de la compra ");monto=t.nextFloat();
         //condicional para mostrar el monto y descuento
         if (monto>=100 && monto<500) {
            descuento=monto*0.10f;
            monto=monto-descuento;
         }else{
            if (monto>=500) {
                descuento=monto*0.20f;
                monto=monto-descuento;
            }
         }
         System.out.println("El valor final a pagar es "+monto);
}
}