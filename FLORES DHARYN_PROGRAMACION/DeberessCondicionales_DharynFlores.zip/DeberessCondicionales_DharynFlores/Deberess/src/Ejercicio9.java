import java.util.Scanner;

public class Ejercicio9 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Declarar variables
        int años,meses,dias,diaAct,mesAct,añoAct,diaNac,mesNac,añoNac;

        // fecha de nacimiento
        System.out.println("Ingrese la fecha de nacimiento");
        System.out.print("Día: ");
        diaNac = teclado.nextInt();
        System.out.print("Mes: ");
        mesNac = teclado.nextInt();
        System.out.print("Año: ");
        añoNac = teclado.nextInt();

        // fecha actual
        System.out.println("Ingrese la fecha actual ");
        System.out.print("Día: ");
        diaAct = teclado.nextInt();
        System.out.print("Mes: ");
        mesAct = teclado.nextInt();
        System.out.print("Año: ");
        añoAct = teclado.nextInt();

        // calcular diferencia
        años = añoAct - añoNac;
        meses = mesAct - mesNac;
        dias = diaAct - diaNac;

        // verificar si el día actual es menor que el de nacimiento
        if (dias < 0) {
            dias += 30;
            meses -= 1;
        }

        // Verificar si el mes actual es menor que el de nacimiento
        if (meses < 0) {
            meses += 12;
            años -= 1;
        }

        // resultado
        if (años < 1) {
            System.out.println("Edad: " + meses + " meses y " + dias + " días.");
        } else {
            System.out.println("Edad: " + años + " años.");
        }

     
    }
}
