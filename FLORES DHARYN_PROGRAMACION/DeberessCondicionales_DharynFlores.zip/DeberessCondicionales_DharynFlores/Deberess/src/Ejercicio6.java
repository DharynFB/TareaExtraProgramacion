import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        //declarar variables 
        float nota;
        //Escribir la nota del estudiante 
        System.out.println("ingrese la nota obtenida por el estudiante ");
        nota=teclado.nextFloat();
        // condicional para determinar la nota obtenida
        if (nota>=90 && nota>=100) {
            System.out.println("su nota obtenida es A");

        }else {
            if (nota<90 && nota>=80) {
                System.out.println("su nota obtenida es una B");

                
            }else{
                if (nota<80 && nota>=70) {
                    
                    System.out.println("su nota obtenida es una C");

                }else{
                    if (nota<70 && nota>=69) {
                        System.out.println("su nota obtenida es una D");
                        
                    }else{
                        if (nota<69&&nota>0) {
                            System.out.println("su nota obtenida es una F");
                            
                        }
                    }
                }
            }
        }
    }
    
}

