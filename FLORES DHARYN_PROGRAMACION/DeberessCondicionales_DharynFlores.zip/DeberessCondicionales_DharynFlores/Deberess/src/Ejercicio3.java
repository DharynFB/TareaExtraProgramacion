import java.util.Scanner;

public class Ejercicio3 {
    public static void main(String[] args) {
        
        Scanner t=new Scanner(System.in);
        //declaracion de variables
        float num;

        System.out.println("ingrese el numero: ");
        num=t.nextFloat();
        
        //condicion if para saber si el numero es par o impar cuando 

        if (num%2==0) {
            System.out.println("el numero es par");
   
        }
        else{
            System.out.println("el numero es impar");
        }
    }    
    
}
