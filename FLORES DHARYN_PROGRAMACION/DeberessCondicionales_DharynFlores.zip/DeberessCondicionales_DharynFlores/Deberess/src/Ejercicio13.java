import java.util.Random;
import java.util.Scanner;

public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        Random random = new Random();
        //declarar variables 
        int vj = 0;
        int vc = 0;
        int rondas = 1;
        int eleccionComputadoraInt;
        String eleccionComputadora = "";
        //imprimir para ver que elige el usuario 
        System.out.println("Ronda " + rondas);
        System.out.print("Elige Piedra, Papel o Tijeras: ");
        String ej = tec.nextLine().toLowerCase();
        //condicional para elegir su opcion 
        if (!ej.equals("piedra") && !ej.equals("papel") && !ej.equals("tijeras")) {
            System.out.print("Entrada inválida. Por favor elige entre Piedra, Papel o Tijeras: ");
            ej = tec.nextLine().toLowerCase();
        }

        eleccionComputadoraInt = random.nextInt(3);
        

        if (eleccionComputadoraInt == 0) {
            eleccionComputadora = "piedra";
        }
        if (eleccionComputadoraInt == 1) {
            eleccionComputadora = "papel";
        }
        if (eleccionComputadoraInt == 2) {
            eleccionComputadora = "tijeras";
        }

        System.out.println("Tu elección: " + ej);
        System.out.println("Elección de la computadora: " + eleccionComputadora);

        if (ej.equals(eleccionComputadora)) {
            System.out.println("Es un empate.");
        }
        if (ej.equals("piedra") && eleccionComputadora.equals("tijeras")) {
            vj++;
            System.out.println("¡Ganaste esta ronda!");
        }
        if (ej.equals("papel") && eleccionComputadora.equals("piedra")) {
            vj++;
            System.out.println("¡Ganaste esta ronda!");
        }
        if (ej.equals("tijeras") && eleccionComputadora.equals("papel")) {
            vj++;
            System.out.println("¡Ganaste esta ronda!");
        }
        if (eleccionComputadora.equals("piedra") && ej.equals("tijeras")) {
            vc++;
            System.out.println("La computadora ganó esta ronda.");
        }
        if (eleccionComputadora.equals("papel") && ej.equals("piedra")) {
            vc++;
            System.out.println("La computadora ganó esta ronda.");
        }
        if (eleccionComputadora.equals("tijeras") && ej.equals("papel")) {
            vc++;
            System.out.println("La computadora ganó esta ronda.");
        }

        System.out.println("Resultado final:");
        System.out.println("Victorias del jugador: " + vj);
        System.out.println("Victorias de la computadora: " + vc);

        if (vj > vc) {
            System.out.println("¡Felicidades! Has ganado el juego.");
        }
        if (vc > vj) {
            System.out.println("La computadora ha ganado el juego.");
        }
        if (vj == vc) {
            System.out.println("Es un empate en el juego.");
        }

       
    }
}
