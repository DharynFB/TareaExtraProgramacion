import java.util.Scanner;

public class Ejercicio12 {
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);

        float a, b, c;

        System.out.println("Ingrese el lado a:");
        a = t.nextFloat();

        System.out.println("Ingrese el lado b:");
        b = t.nextFloat();

        System.out.println("Ingrese el lado c:");
        c = t.nextFloat();

        // Verificar que tipo de triangulo es 
        if ((a + b > c) && (a + c > b) && (b + c > a)) {
            if (a == b && b == c) {
                System.out.println("El triángulo es EQUILÁTERO.");
            } else if (a == b || a == c || b == c) {
                System.out.println("El triángulo es ISÓSCELES.");
            } else {
                System.out.println("El triángulo es ESCALENO.");
            }
        } else {
            System.out.println("Los lados no forman un triángulo válido.");
        }

    }
}
