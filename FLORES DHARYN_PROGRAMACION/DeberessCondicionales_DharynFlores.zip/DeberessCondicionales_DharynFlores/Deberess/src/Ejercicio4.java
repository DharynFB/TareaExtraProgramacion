import java.util.Scanner;

public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        //declarar variables
        int dia,mes,año,diasEnElMes;
        boolean esBisiesto;

        // Entrada
        System.out.println("Introduce la fecha en formato: dd/ mm/ aaaa:");
        System.out.print("Día: ");dia = t.nextInt();
         

        System.out.print("Mes: ");mes = t.nextInt();
         

        System.out.print("Año: "); año = t.nextInt();
         

        // Verificar si el año es bisiesto
        esBisiesto = (año % 4 == 0 && año % 100 != 0) || (año % 400 == 0);

        // Determinar días del mes
         diasEnElMes = 0;
        if (mes == 2) {
            diasEnElMes = esBisiesto ? 29 : 28;
        } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
            diasEnElMes = 30;
        } else if (mes >= 1 && mes <= 12) {
            diasEnElMes = 31;
        } else {
            System.out.println("Mes inválido.");
            return;
        }

        // Validación básica del día
        if (dia < 1 || dia > diasEnElMes) {
            System.out.println("Día inválido para ese mes.");
            return;
        }

        // Calcular fecha siguiente
        dia++; // Avanzamos un día

        if (dia > diasEnElMes) {
            dia = 1;
            mes++;
            if (mes > 12) {
                mes = 1;
                año++;
            }
        }

        // Salida
        System.out.println("La fecha del día siguiente es: " + dia + "/ " + mes + "/ " + año);

        
    }
}

