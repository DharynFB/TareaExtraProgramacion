import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        
        Scanner t= new Scanner(System.in);

        //declaracion de varaibles

        float num; 
        
        //pedir al usuario que ingrese mediante teclado el numero que desee saber cual es su raiz 

        System.out.println("ingrese el numero que desee calcular la raiz");
        num=t.nextFloat();
        //proceso para saber cual es la raiz del numero ingresado 

        if (num>0) {
            System.out.println("la raiz de "+num+" es "+Math.sqrt(num));
  
        }
        else{
            System.out.println("el numero no puede ser negativo");
        }
       
    }
}
