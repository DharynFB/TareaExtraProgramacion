import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);

        // Declarar variables
        float num1, num2;
        int seleccionOp;

        // Solicitar al usuario dos números
        System.out.print("Ingresa el primer número: ");
        num1 = t.nextFloat();

        System.out.print("Ingresa el segundo número: ");
        num2 = t.nextFloat();

        // Mostrar opciones de operación
        System.out.println("Selecciona una operación:");
        System.out.println("1. Suma");
        System.out.println("2. Resta");
        System.out.println("3. Multiplicación");
        System.out.println("4. División");

        System.out.print("Ingresa el número de la operación deseada: ");
        seleccionOp = t.nextInt();

        // Ejecutar operaciones
        if (seleccionOp == 1) {
            System.out.println("El resultado de la suma es: " + (num1 + num2));
        } else if (seleccionOp == 2) {
            System.out.println("Resultado de la resta es: " + (num1 - num2));
        } else if (seleccionOp == 3) {
            System.out.println("Resultado de la multiplicacion es: " + (num1 * num2));
        } else if (seleccionOp == 4) {
            if (num2 != 0) {
                System.out.println("Resultado de la division es: " + (num1 / num2));
            } else {
                System.out.println("no puede ser hacer division por cero.");
            }
        } else {
            System.out.println("Operación no válida.");
        }
    }
}
