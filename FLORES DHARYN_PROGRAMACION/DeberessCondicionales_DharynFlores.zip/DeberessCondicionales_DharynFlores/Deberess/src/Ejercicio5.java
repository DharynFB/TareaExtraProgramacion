import java.util.Scanner;

public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner t=new Scanner(System.in);

        //declaracion de variables 

        float num1,num2;
        //pedir al usuario ingresar los numeros
        System.out.println("escriba el primer numero: ");
        num1=t.nextFloat();
        System.out.println("escriba el segundo numero: ");
        num2=t.nextFloat();

        //condicion para saber como un numero es divisor del otro 

        if (num1==0 && num2==0) {

           System.out.println("no se puede dividir entre cero");

            
        }else if (num1%num2==0) {
            System.out.println(num2+" es divisor de "+num1);

            
        }else if (num2%num1==0) {
            System.out.println(num1+" es divisor de "+num2);

            
        }else{
        
            System.out.println("ningun numero es divisor del otro");
        }

        
    }
    
}
