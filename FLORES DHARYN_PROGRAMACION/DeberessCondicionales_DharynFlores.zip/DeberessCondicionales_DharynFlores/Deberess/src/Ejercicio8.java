import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        
        Scanner t=new Scanner(System.in);
       //declarar variables 

        int num1,num2,num3;

       //pedir al usuario que ingrese los tres numeros enteros 

        System.out.println("ingresa el primer numero: ");
        num1=t.nextInt();
        System.out.println("ingresa el primer numero: ");
        num2=t.nextInt();
        System.out.println("ingresa el primer numero: ");
        num3=t.nextInt();
        
        //verificar con el if que mi numero este en orden numerico 

        if (num1<=num2&&num2<=num3) {
            System.out.println("Los numeros ingresados estan en orden numerico");
            
        }else{
            System.out.println("los numeros no esta en orden numerico");
        }
        
    }
    
}
